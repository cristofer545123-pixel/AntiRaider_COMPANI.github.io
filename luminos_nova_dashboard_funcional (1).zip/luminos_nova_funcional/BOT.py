"""
Bot multifunción para Discord (discord.py 2.x)  ·  Luminos Nova
- Panel de control (/panel) con categorías, iconos y variables editables
- Protegido con KEY de seguridad (/acceso)
- Antiraid + lista negra, Sorteos, Invite tracker, Seguridad, Diversión/Economía/Niveles,
  Logs, Tickets, Moderación y /sys_time (tiempo entre mensajes por ID)

Instalación:  py -m pip install -U discord.py cryptography
Ejecución:    py bot.py   (la primera vez crea config.json)
"""

import asyncio
import base64
import copy
import getpass
import hashlib
import hmac
import io
import json
import os
import random
import re
import secrets
import sys
import time
import unicodedata
from collections import defaultdict, deque
from datetime import timedelta
from typing import Optional

import discord
from aiohttp import web
from discord import app_commands
from discord.ext import commands, tasks

# =====================================================================
#  CONFIGURACIÓN Y SEGURIDAD (token cifrado + key + lista de acceso)
# =====================================================================
CONFIG_FILE = "config.json"
DATA_FILE = "data.json"
AUTH_TTL = 30 * 60  # la sesión del panel dura 30 minutos
PLACEHOLDER_TOKEN = "PEGA_AQUI_TU_TOKEN"
PLACEHOLDER_KEY = "CAMBIA_ESTA_KEY"

# LISTA BLANCA DE SERVIDORES AUTORIZADOS.
# Deja el conjunto vacío para que el bot permanezca INACTIVO en todos los servidores.
ALLOWED_GUILD_IDS: set[int] = {
    1523027427331407892,
    1561208865553522690,
}


def guild_is_allowed(guild_id: int | None) -> bool:
    return guild_id is not None and guild_id in ALLOWED_GUILD_IDS


try:
    from cryptography.fernet import Fernet, InvalidToken
except ImportError:
    print("Falta la librería 'cryptography'. Instálala con:  py -m pip install cryptography")
    sys.exit(1)


def hash_key(key: str, salt: str) -> str:
    return hashlib.pbkdf2_hmac("sha256", key.encode(), salt.encode(), 200_000).hex()


def _fernet(password: str, salt_hex: str) -> Fernet:
    raw = hashlib.pbkdf2_hmac("sha256", password.encode(), bytes.fromhex(salt_hex), 600_000, dklen=32)
    return Fernet(base64.urlsafe_b64encode(raw))


def _write_config(cfg: dict) -> None:
    with open(CONFIG_FILE, "w", encoding="utf-8") as f:
        json.dump(cfg, f, indent=2)


def ask_new_password() -> str:
    while True:
        p1 = getpass.getpass("Crea una contraseña maestra (mín. 8 caracteres): ")
        if len(p1) < 8:
            print("Demasiado corta.")
            continue
        if p1 != getpass.getpass("Repítela: "):
            print("No coinciden.")
            continue
        return p1


def load_config() -> dict:
    if not os.path.exists(CONFIG_FILE):
        _write_config({"owner_id": 0, "token": PLACEHOLDER_TOKEN, "panel_key": PLACEHOLDER_KEY})
        print("Se creó config.json. Ábrelo y rellena:")
        print("  owner_id  -> TU ID de usuario de Discord (modo desarrollador -> clic derecho en tu perfil -> Copiar ID)")
        print("  token     -> el token de tu bot")
        print("  panel_key -> una key propia (mín. 6 caracteres)")
        print("Luego ejecuta de nuevo.")
        sys.exit(0)

    with open(CONFIG_FILE, "r", encoding="utf-8") as f:
        cfg = json.load(f)
    changed = False

    try:
        owner = int(cfg.get("owner_id", 0))
    except (TypeError, ValueError):
        owner = 0
    if owner <= 0:
        print("Pon tu ID de Discord en 'owner_id' dentro de config.json.")
        sys.exit(0)
    cfg["owner_id"] = owner

    if "panel_key" in cfg:
        if cfg["panel_key"] == PLACEHOLDER_KEY or len(cfg["panel_key"]) < 6:
            print("Cambia 'panel_key' en config.json por una key propia (mín. 6 caracteres).")
            sys.exit(0)
        salt = secrets.token_hex(16)
        cfg["salt"] = salt
        cfg["key_hash"] = hash_key(cfg.pop("panel_key"), salt)
        changed = True
        print("🔐 Tu key fue protegida con hash y ya no aparece en config.json. ¡Guárdala bien!")
        print("   (Si la olvidas, agrega \"panel_key\": \"nueva\" al config.json y se reemplaza.)")

    if "token" in cfg:
        if cfg["token"] == PLACEHOLDER_TOKEN or len(cfg["token"]) < 30:
            print("Pon el token real de tu bot en config.json (campo 'token').")
            sys.exit(0)
        print("🔐 Vamos a cifrar tu token. Sin la contraseña maestra nadie podrá usarlo.")
        password = ask_new_password()
        token_salt = secrets.token_hex(16)
        cfg["token_salt"] = token_salt
        cfg["token_enc"] = _fernet(password, token_salt).encrypt(cfg.pop("token").encode()).decode()
        changed = True
        print("✅ Token cifrado. Ya no aparece en texto plano en config.json.")

    if "token_enc" not in cfg or "key_hash" not in cfg:
        print("config.json está incompleto. Bórralo y vuelve a generarlo.")
        sys.exit(1)

    if changed:
        _write_config(cfg)
    return cfg


def get_token(cfg: dict) -> str:
    password = os.getenv("BOT_MASTER_PASSWORD") or getpass.getpass("🔑 Contraseña maestra del bot: ")
    try:
        return _fernet(password, cfg["token_salt"]).decrypt(cfg["token_enc"].encode()).decode()
    except InvalidToken:
        print("❌ Contraseña incorrecta.")
        sys.exit(1)


CONFIG = load_config()
OWNER_ID = int(CONFIG["owner_id"])

auth_sessions: dict[int, float] = {}          # user_id -> expira
failed_attempts: dict[int, tuple] = {}        # user_id -> (fallos, bloqueado_hasta)


def is_authed(user_id: int) -> bool:
    exp = auth_sessions.get(user_id)
    return bool(exp and exp > time.time())


def is_allowed(user_id: int) -> bool:
    """Solo el dueño y las personas que él autorice."""
    return user_id == OWNER_ID or user_id in data.get("allowed", [])


class NotAuthed(app_commands.CheckFailure):
    pass


class NotAllowed(app_commands.CheckFailure):
    pass


class NotOwner(app_commands.CheckFailure):
    pass


def _deny_log(interaction: discord.Interaction) -> None:
    name = interaction.command.name if interaction.command else "?"
    print(f"⛔ Acceso denegado: {interaction.user} ({interaction.user.id}) intentó /{name}")


def requires_allowed():
    async def predicate(interaction: discord.Interaction) -> bool:
        if is_allowed(interaction.user.id):
            return True
        _deny_log(interaction)
        raise NotAllowed()
    return app_commands.check(predicate)


def requires_key():
    """Debe estar autorizado Y haber iniciado sesión con la key."""
    async def predicate(interaction: discord.Interaction) -> bool:
        uid = interaction.user.id
        if not is_allowed(uid):
            _deny_log(interaction)
            raise NotAllowed()
        if is_authed(uid):
            return True
        raise NotAuthed()
    return app_commands.check(predicate)


def owner_only():
    async def predicate(interaction: discord.Interaction) -> bool:
        if interaction.user.id == OWNER_ID:
            return True
        _deny_log(interaction)
        raise NotOwner()
    return app_commands.check(predicate)


# =====================================================================
#  DATOS (JSON)
# =====================================================================
def load_data() -> dict:
    d = {}
    if os.path.exists(DATA_FILE):
        try:
            with open(DATA_FILE, "r", encoding="utf-8") as f:
                d = json.load(f)
        except (json.JSONDecodeError, OSError):
            d = {}
    for k in ("guilds", "blacklist", "invites", "economy", "giveaways", "allies", "embeds"):
        d.setdefault(k, {})
    d.setdefault("allowed", [])
    return d


data = load_data()
_dirty = False


def save_data() -> None:
    tmp = DATA_FILE + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=1, ensure_ascii=False)
    os.replace(tmp, DATA_FILE)


def mark_dirty() -> None:
    global _dirty
    _dirty = True


@tasks.loop(seconds=30)
async def autosave():
    global _dirty
    if _dirty:
        _dirty = False
        save_data()


# =====================================================================
#  VARIABLES DEL PANEL (categorías, iconos, valores por defecto)
#  vars = (clave, etiqueta, tipo)   tipos: bool, int, text, list, channel, role, choice:a,b
#  Límite de Discord: máx. 10 variables "bool" por categoría (se muestran como botones).
# =====================================================================
CATS = {
    "antiraid": {
        "emoji": "🛡️", "name": "Antiraid", "short": "Raids, bots y cuentas sospechosas", "color": 0xE74C3C,
        "desc": "Protege el servidor contra oleadas de entradas, bots no autorizados y cuentas sospechosas.\n"
                "• La lista negra (`/sys_lock`) siempre está activa.\n"
                "• `/sys_raid` activa un **bloqueo manual** de entradas en caso de emergencia.",
        "vars": [
            ("enabled", "🛡️ Antiraid", "bool"),
            ("block_bots", "🤖 Bloquear bots", "bool"),
            ("no_avatar", "👤 Bloquear sin avatar", "bool"),
            ("dm_notify", "📩 Avisar por DM al sancionar", "bool"),
            ("join_limit", "👥 Máx. entradas (0 = off)", "int"),
            ("join_window", "⏱️ Ventana (seg)", "int"),
            ("min_age", "📅 Edad mín. cuenta (días)", "int"),
            ("lockdown_secs", "🚨 Duración del modo raid (seg)", "int"),
            ("action", "⚔️ Acción", "choice:kick,ban,timeout"),
            ("bot_whitelist", "✅ Bots permitidos (IDs)", "list"),
            ("name_filter", "🏷️ Nombres prohibidos", "list"),
            ("alert_channel", "📢 Canal de alertas", "channel"),
            ("dm_embed", "🖼️ Embed del DM", "embed"),
        ],
    },
    "sorteos": {
        "emoji": "🎉", "name": "Sorteos", "short": "Sistema de giveaway", "color": 0xF1C40F,
        "desc": "Configura el sistema de sorteos. Crea uno con `/event_start`.",
        "vars": [
            ("dm_winner", "📩 Avisar por DM", "bool"),
            ("channel", "📢 Canal por defecto", "channel"),
            ("ping_role", "🔔 Rol a mencionar", "role"),
            ("default_winners", "🏆 Ganadores por defecto", "int"),
            ("winner_embed", "🖼️ Embed de ganadores", "embed"),
        ],
    },
    "invites": {
        "emoji": "📨", "name": "Invite", "short": "Invite tracker", "color": 0x3498DB,
        "desc": "Rastrea quién invita a quién. Consulta con `/invite_stats` y `/invite_rank`.\n"
                "El bot necesita el permiso **Gestionar servidor**.",
        "vars": [
            ("enabled", "📨 Rastreador", "bool"),
            ("announce", "💬 Anunciar entradas", "bool"),
            ("channel", "📢 Canal de avisos", "channel"),
            ("join_embed", "🖼️ Embed de entrada", "embed"),
        ],
    },
    "proteccion": {
        "emoji": "🔐", "name": "Seguridad", "short": "Antispam, enlaces y palabras", "color": 0x9B59B6,
        "desc": "Filtros automáticos de chat.\n"
                "⚠️ Con **Staff exento** activado, administradores y moderadores (Gestionar mensajes) "
                "**no** son filtrados. Desactívalo para probar con tu cuenta.",
        "vars": [
            ("antilinks", "🔗 Antienlaces", "bool"),
            ("antispam", "💥 Antispam", "bool"),
            ("badwords_on", "🤬 Filtro de palabras", "bool"),
            ("anticaps", "🔠 Anti-mayúsculas", "bool"),
            ("check_edits", "✏️ Revisar mensajes editados", "bool"),
            ("strict", "🕵️ Modo estricto (leet, tildes, repetidas)", "bool"),
            ("exempt_staff", "👮 Staff exento", "bool"),
            ("notify", "⚠️ Avisar en el canal", "bool"),
            ("badwords_mode", "🎯 Modo de palabras", "choice:smart,word,contains"),
            ("badwords", "📝 Palabras prohibidas", "list"),
            ("link_whitelist", "🌐 Dominios permitidos", "list"),
            ("mention_limit", "📣 Máx. menciones (0 = off)", "int"),
            ("caps_percent", "🔠 % de mayúsculas máx.", "int"),
            ("spam_limit", "📨 Mensajes máx.", "int"),
            ("spam_window", "⏱️ Ventana spam (seg)", "int"),
            ("timeout_min", "🔇 Timeout por spam (min)", "int"),
            ("bypass_role", "🛂 Rol exento", "role"),
            ("warn_embed", "🖼️ Embed de aviso", "embed"),
        ],
    },
    "diversion": {
        "emoji": "🎮", "name": "Diversión", "short": "Economía, niveles y juegos", "color": 0xE91E63,
        "desc": "Economía, niveles y comandos de diversión: `/claim` `/shift` `/wallet` `/wager` "
                "`/level` `/wealth` `/oracle` `/hug` y más.",
        "vars": [
            ("enabled", "🎮 Módulo", "bool"),
            ("levels", "📈 Niveles por chat", "bool"),
            ("level_messages", "💬 Anunciar subidas de nivel", "bool"),
            ("currency", "💰 Moneda", "text"),
            ("daily", "🎁 Recompensa diaria", "int"),
            ("work_min", "⛏️ Trabajo mínimo", "int"),
            ("work_max", "⛏️ Trabajo máximo", "int"),
            ("level_channel", "📢 Canal de niveles", "channel"),
            ("level_embed", "🖼️ Embed de nivel", "embed"),
        ],
    },
    "logs": {
        "emoji": "📜", "name": "Logs", "short": "Registro de actividad", "color": 0x95A5A6,
        "desc": "Registra mensajes borrados/editados, entradas, salidas, baneos y sanciones automáticas.",
        "vars": [
            ("enabled", "📜 Logs", "bool"),
            ("log_messages", "💬 Mensajes", "bool"),
            ("log_members", "👤 Miembros", "bool"),
            ("log_mod", "🔨 Moderación", "bool"),
            ("channel", "📢 Canal de logs", "channel"),
        ],
    },
    "tickets": {
        "emoji": "🎫", "name": "Ticket", "short": "Sistema de tickets", "color": 0x2ECC71,
        "desc": "Sistema de soporte con canales privados y transcripciones.\n"
                "Envía el panel con `/sys_support`.",
        "vars": [
            ("transcripts", "📄 Transcripciones", "bool"),
            ("staff_role", "🛠️ Rol staff", "role"),
            ("category", "📁 Categoría", "channel"),
            ("log_channel", "📢 Canal de logs", "channel"),
            ("welcome", "💬 Mensaje inicial del ticket", "text"),
            ("welcome_embed", "🖼️ Embed del ticket", "embed"),
            ("panel_embed", "🖼️ Embed del panel", "embed"),
        ],
    },
    "bienvenida": {
        "emoji": "👋", "name": "Bienvenida", "short": "Bienvenida, despedida y autorol", "color": 0x1ABC9C,
        "desc": "Mensajes de bienvenida/despedida y rol automático.\n"
                "Variables: usuario, servidor, iconos/avatares, canal, fecha y variables de alianzas. Usa `/variables` para ver la guía completa.\n"
                "💡 Puedes usar un **embed guardado** (`/embed create:nombre`) en vez del texto.",
        "vars": [
            ("welcome_on", "👋 Bienvenida", "bool"),
            ("goodbye_on", "🚪 Despedida", "bool"),
            ("use_embed", "🧩 Usar embed", "bool"),
            ("welcome_dm", "📩 Enviar por DM", "bool"),
            ("welcome_channel", "📢 Canal de bienvenida", "channel"),
            ("goodbye_channel", "📢 Canal de despedida", "channel"),
            ("autorole", "🏷️ Autorol", "role"),
            ("welcome_title", "🔤 Título (embed)", "text"),
            ("welcome_msg", "💬 Mensaje de bienvenida", "text"),
            ("goodbye_msg", "💬 Mensaje de despedida", "text"),
            ("welcome_image", "🖼️ Imagen (URL)", "text"),
            ("welcome_embed", "🖼️ Embed de bienvenida", "embed"),
            ("goodbye_embed", "🖼️ Embed de despedida", "embed"),
        ],
    },
    "aliados": {
        "emoji": "🤝", "name": "Aliados", "short": "Alianzas y afiliados", "color": 0x16A085,
        "desc": "Gestiona alianzas con otros servidores: `/ally_add` `/ally_list` "
                "`/ally_remove`.",
        "vars": [
            ("enabled", "🤝 Alianzas", "bool"),
            ("channel", "📢 Canal de alianzas", "channel"),
            ("role", "🏷️ Rol de aliado", "role"),
            ("thanks", "💬 Mensaje de agradecimiento", "text"),
            ("embed", "🖼️ Embed de alianza", "embed"),
        ],
    },
}

COMMANDS_BY_CAT = {
    'antiraid': ['`/sys_lock`', '`/sys_unlock`', '`/sys_records`', '`/sys_raid`'],
    'sorteos': ['`/event_start`', '`/event_end`', '`/event_reroll`'],
    'invites': ['`/invite_stats`', '`/invite_rank`'],
    'proteccion': ['`/sys_sweep`', '`/sys_timeout`'],
    'diversion': ['`/wallet`', '`/claim`', '`/shift`', '`/wager`', '`/transfer`', '`/wealth`', '`/level`',
                  '`/oracle`', '`/coinflip`', '`/hug`', '`/pfp`'],
    'logs': ['*(Eventos automáticos; se configura desde esta sección.)*'],
    'tickets': ['`/sys_support`', '`/ticket_add`'],
    'bienvenida': ['*(Eventos automáticos; se configura desde esta sección.)*'],
    'aliados': ['`/ally_add`', '`/ally_list`', '`/ally_remove`'],
}


DEFAULTS = {
    "antiraid": {"enabled": False, "block_bots": False, "no_avatar": False, "dm_notify": True,
                 "join_limit": 5, "join_window": 10, "min_age": 3, "lockdown_secs": 60,
                 "action": "kick", "bot_whitelist": [], "name_filter": [], "alert_channel": None,
                 "dm_embed": None},
    "sorteos": {"dm_winner": True, "channel": None, "ping_role": None, "default_winners": 1,
                "winner_embed": None},
    "invites": {"enabled": False, "announce": True, "channel": None, "join_embed": None},
    "proteccion": {"antilinks": False, "antispam": False, "badwords_on": False, "anticaps": False,
                   "check_edits": True, "strict": True, "exempt_staff": True, "notify": True,
                   "badwords_mode": "smart", "badwords": [], "link_whitelist": [],
                   "mention_limit": 0, "caps_percent": 70,
                   "spam_limit": 5, "spam_window": 5, "timeout_min": 5, "bypass_role": None,
                   "warn_embed": None},
    "diversion": {"enabled": True, "levels": True, "currency": "🪙", "daily": 200, "work_min": 50,
                  "work_max": 200, "level_channel": None, "level_messages": False, "level_embed": None},
    "logs": {"enabled": False, "log_messages": True, "log_members": True, "log_mod": True, "channel": None},
    "tickets": {"transcripts": True, "staff_role": None, "category": None, "log_channel": None,
                "welcome": "¡Gracias por abrir un ticket! Un miembro del staff te atenderá pronto.",
                "counter": 0, "welcome_embed": None, "panel_embed": None},
    "bienvenida": {"welcome_on": False, "goodbye_on": False, "use_embed": True, "welcome_dm": False,
                   "welcome_channel": None, "goodbye_channel": None, "autorole": None,
                   "welcome_title": "👋 ¡Bienvenido!",
                   "welcome_msg": "¡Hola {user}! Bienvenido a **{server}**. Eres el miembro #{count} 🎉",
                   "goodbye_msg": "👋 **{username}** salió de **{server}**.", "welcome_image": "",
                   "welcome_embed": None, "goodbye_embed": None},
    "aliados": {"enabled": False, "channel": None, "role": None, "thanks": "¡Gracias por la alianza! 💙",
                "embed": None},
}


def gcfg(guild_id: int, cat: str) -> dict:
    g = data["guilds"].setdefault(str(guild_id), {})
    c = g.setdefault(cat, {})
    for k, v in DEFAULTS[cat].items():
        if k not in c:
            c[k] = copy.deepcopy(v)
    return c


def render_value(kind: str, value) -> str:
    if kind == "bool":
        return "✅ Activado" if value else "❌ Desactivado"
    if kind == "channel":
        return f"<#{value}>" if value else "— sin definir —"
    if kind == "role":
        return f"<@&{value}>" if value else "— sin definir —"
    if kind == "embed":
        return f"🖼️ `{value}`" if value else "— sin definir —"
    if kind == "list":
        text = ", ".join(f"`{x}`" for x in value) if value else "— vacía —"
        return text if len(text) <= 300 else text[:297] + "…"
    return f"`{value}`" if value not in (None, "") else "— vacío —"


def parse_value(guild: discord.Guild, kind: str, raw: str):
    raw = raw.strip()
    if kind == "int":
        try:
            val = int(raw)
        except ValueError:
            raise ValueError("Debe ser un número entero.")
        if val < 0:
            raise ValueError("No puede ser negativo.")
        return val
    if kind.startswith("choice:"):
        opts = kind.split(":", 1)[1].split(",")
        if raw.lower() not in opts:
            raise ValueError(f"Opciones válidas: {', '.join(opts)}")
        return raw.lower()
    if kind in ("channel", "role"):
        if not raw:
            return None
        m = re.search(r"\d{15,20}", raw)
        if not m:
            raise ValueError("Usa una mención o el ID.")
        obj = guild.get_channel(int(m.group())) if kind == "channel" else guild.get_role(int(m.group()))
        if obj is None:
            raise ValueError("No encontré ese canal/rol en este servidor.")
        return obj.id
    if kind == "list":
        return [x.strip().lower() for x in re.split(r"[,\n]", raw) if x.strip()]
    return raw


def hint_for(kind: str) -> str:
    if kind == "int":
        return "Número entero"
    if kind.startswith("choice:"):
        return "Opciones: " + kind.split(":", 1)[1].replace(",", " / ")
    if kind == "channel":
        return "Elige un canal"
    if kind == "role":
        return "Elige un rol"
    if kind == "list":
        return "Añadir / quitar elementos"
    if kind == "embed":
        return "Elige un embed guardado"
    return "Texto"


def build_embed(guild: discord.Guild, cat: str) -> discord.Embed:
    meta = CATS[cat]
    cfg = gcfg(guild.id, cat)
    e = discord.Embed(title=f"{meta['emoji']} {meta['name']}", description=meta["desc"], color=meta["color"])
    e.set_author(name="Variables | Configuración")
    for key, label, kind in meta["vars"]:
        e.add_field(name=label, value=render_value(kind, cfg[key]), inline=True)
    command_list = COMMANDS_BY_CAT.get(cat, [])
    if command_list:
        e.add_field(name="📜 Comandos de esta sección",
                    value=" • ".join(command_list)[:1024], inline=False)
    e.set_footer(text=f"{guild.name} • Panel de control • sesión activa")
    if guild.icon:
        e.set_thumbnail(url=guild.icon.url)
    return e


# =====================================================================
#  PANEL DE CONTROL (UI)
#  Distribución fija de filas (Discord permite 5 filas por mensaje):
#    fila 0 → categorías | filas 1-2 → interruptores | fila 3 → editar | fila 4 → acciones
# =====================================================================
class SecureView(discord.ui.View):
    """Base: solo el dueño del panel, autorizado y con sesión activa, puede usarla."""

    def __init__(self, owner_id: int, guild: discord.Guild, cat: str, timeout: float = 900):
        super().__init__(timeout=timeout)
        self.owner_id, self.guild, self.cat = owner_id, guild, cat

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id != self.owner_id:
            await interaction.response.send_message("Este panel no es tuyo.", ephemeral=True)
            return False
        if not is_allowed(interaction.user.id):
            await interaction.response.send_message("⛔ Ya no tienes acceso al panel.", ephemeral=True)
            return False
        if not is_authed(interaction.user.id):
            await interaction.response.send_message("🔒 Sesión expirada. Usa `/acceso`.", ephemeral=True)
            return False
        if interaction.guild_id != self.guild.id or not guild_is_allowed(interaction.guild_id):
            await interaction.response.send_message("Este panel solo sirve en el servidor original.", ephemeral=True)
            return False
        return True

    async def back_to_panel(self, interaction: discord.Interaction):
        await interaction.response.edit_message(
            content=None, embed=build_embed(self.guild, self.cat),
            view=PanelView(self.owner_id, self.guild, self.cat))


class CategorySelect(discord.ui.Select):
    def __init__(self, current: str):
        opts = [
            discord.SelectOption(label=m["name"], value=k, emoji=m["emoji"], description=m["short"][:100],
                                 default=(k == current))
            for k, m in CATS.items()
        ]
        super().__init__(placeholder="📂 Elige una categoría…", options=opts, min_values=1, max_values=1, row=0)

    async def callback(self, interaction: discord.Interaction):
        cat = self.values[0]
        v = self.view
        await interaction.response.edit_message(
            embed=build_embed(interaction.guild, cat),
            view=PanelView(v.owner_id, interaction.guild, cat))


class ToggleButton(discord.ui.Button):
    def __init__(self, key: str, label: str, state: bool, row: int):
        text = label.split(" ", 1)[-1] if " " in label else label  # quita el emoji del texto
        super().__init__(label=text[:80], emoji="✅" if state else "❌",
                         style=discord.ButtonStyle.success if state else discord.ButtonStyle.secondary,
                         row=row)
        self.key = key

    async def callback(self, interaction: discord.Interaction):
        v = self.view
        cfg = gcfg(interaction.guild.id, v.cat)
        cfg[self.key] = not cfg[self.key]
        save_data()
        await interaction.response.edit_message(
            embed=build_embed(interaction.guild, v.cat),
            view=PanelView(v.owner_id, interaction.guild, v.cat))


class EditSelect(discord.ui.Select):
    def __init__(self, others: list):
        self.meta = {k: (label, kind) for k, label, kind in others}
        opts = [discord.SelectOption(label=label[:100], value=k, description=hint_for(kind)[:100])
                for k, label, kind in others]
        super().__init__(placeholder="✏️ Editar una variable…", options=opts[:25],
                         min_values=1, max_values=1, row=3)

    async def callback(self, interaction: discord.Interaction):
        v = self.view
        key = self.values[0]
        label, kind = self.meta[key]
        args = (v.owner_id, v.guild, v.cat, key, label)
        if kind == "channel":
            await interaction.response.edit_message(
                embed=picker_embed("📢", label, "Selecciona un canal o quita la configuración."),
                view=ChannelPickerView(*args))
        elif kind == "role":
            await interaction.response.edit_message(
                embed=picker_embed("🏷️", label, "Selecciona un rol o quita la configuración."),
                view=RolePickerView(*args))
        elif kind == "embed":
            has = bool(embed_store(v.guild.id))
            await interaction.response.edit_message(
                embed=picker_embed("🖼️", label,
                                   "Elige uno de tus embeds guardados." if has else
                                   "Aún no tienes embeds guardados.\nCrea uno con `/embed create:nombre` y vuelve aquí."),
                view=EmbedPickerView(*args))
        elif kind == "list":
            ed = ListEditorView(*args)
            await interaction.response.edit_message(embed=ed.embed(), view=ed)
        elif kind.startswith("choice:"):
            await interaction.response.edit_message(
                embed=picker_embed("🎯", label, "Elige una opción."),
                view=ChoicePickerView(*args, kind=kind))
        else:
            modal = EditModal(v, key, label, kind)
            modal.message = interaction.message
            await interaction.response.send_modal(modal)


def picker_embed(icon: str, label: str, text: str) -> discord.Embed:
    return discord.Embed(title=f"{icon} {label}", description=text, color=0x8B5CF6)


class ChannelPickerView(SecureView):
    def __init__(self, owner_id, guild, cat, key: str, label: str):
        super().__init__(owner_id, guild, cat, timeout=180)
        self.key, self.label = key, label
        sel = discord.ui.ChannelSelect(
            placeholder="Haz clic y elige un canal…", min_values=1, max_values=1, row=0,
            channel_types=[discord.ChannelType.text, discord.ChannelType.news, discord.ChannelType.voice,
                           discord.ChannelType.stage_voice, discord.ChannelType.category,
                           discord.ChannelType.forum])
        sel.callback = self.on_pick
        self.sel = sel
        self.add_item(sel)

    async def on_pick(self, interaction: discord.Interaction):
        gcfg(self.guild.id, self.cat)[self.key] = self.sel.values[0].id
        save_data()
        await self.back_to_panel(interaction)

    @discord.ui.button(label="Quitar", emoji="🗑️", style=discord.ButtonStyle.danger, row=1)
    async def clear(self, interaction: discord.Interaction, button: discord.ui.Button):
        gcfg(self.guild.id, self.cat)[self.key] = None
        save_data()
        await self.back_to_panel(interaction)

    @discord.ui.button(label="Volver", emoji="↩️", style=discord.ButtonStyle.secondary, row=1)
    async def back(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self.back_to_panel(interaction)


class RolePickerView(SecureView):
    def __init__(self, owner_id, guild, cat, key: str, label: str):
        super().__init__(owner_id, guild, cat, timeout=180)
        self.key, self.label = key, label
        sel = discord.ui.RoleSelect(placeholder="Haz clic y elige un rol…", min_values=1, max_values=1, row=0)
        sel.callback = self.on_pick
        self.sel = sel
        self.add_item(sel)

    async def on_pick(self, interaction: discord.Interaction):
        gcfg(self.guild.id, self.cat)[self.key] = self.sel.values[0].id
        save_data()
        await self.back_to_panel(interaction)

    @discord.ui.button(label="Quitar", emoji="🗑️", style=discord.ButtonStyle.danger, row=1)
    async def clear(self, interaction: discord.Interaction, button: discord.ui.Button):
        gcfg(self.guild.id, self.cat)[self.key] = None
        save_data()
        await self.back_to_panel(interaction)

    @discord.ui.button(label="Volver", emoji="↩️", style=discord.ButtonStyle.secondary, row=1)
    async def back(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self.back_to_panel(interaction)


class EmbedPickerView(SecureView):
    """Elige un embed guardado (/embed create:nombre) para usarlo en una función."""

    def __init__(self, owner_id, guild, cat, key: str, label: str):
        super().__init__(owner_id, guild, cat, timeout=180)
        self.key, self.label = key, label
        names = sorted(embed_store(guild.id))[:25]
        if names:
            current = gcfg(guild.id, cat)[key]
            sel = discord.ui.Select(
                placeholder="Elige un embed guardado…", min_values=1, max_values=1, row=0,
                options=[discord.SelectOption(label=n, value=n, emoji="🖼️", default=(n == current))
                         for n in names])
            sel.callback = self.on_pick
            self.sel = sel
            self.add_item(sel)

    async def on_pick(self, interaction: discord.Interaction):
        gcfg(self.guild.id, self.cat)[self.key] = self.sel.values[0]
        save_data()
        await self.back_to_panel(interaction)

    @discord.ui.button(label="Quitar", emoji="🗑️", style=discord.ButtonStyle.danger, row=1)
    async def clear(self, interaction: discord.Interaction, button: discord.ui.Button):
        gcfg(self.guild.id, self.cat)[self.key] = None
        save_data()
        await self.back_to_panel(interaction)

    @discord.ui.button(label="Volver", emoji="↩️", style=discord.ButtonStyle.secondary, row=1)
    async def back(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self.back_to_panel(interaction)


class ChoicePickerView(SecureView):
    def __init__(self, owner_id, guild, cat, key: str, label: str, kind: str):
        super().__init__(owner_id, guild, cat, timeout=180)
        self.key, self.label = key, label
        current = gcfg(guild.id, cat)[key]
        opts = [discord.SelectOption(label=o, value=o, default=(o == current))
                for o in kind.split(":", 1)[1].split(",")]
        sel = discord.ui.Select(placeholder="Elige una opción…", options=opts, min_values=1, max_values=1, row=0)
        sel.callback = self.on_pick
        self.sel = sel
        self.add_item(sel)

    async def on_pick(self, interaction: discord.Interaction):
        gcfg(self.guild.id, self.cat)[self.key] = self.sel.values[0]
        save_data()
        await self.back_to_panel(interaction)

    @discord.ui.button(label="Volver", emoji="↩️", style=discord.ButtonStyle.secondary, row=1)
    async def back(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self.back_to_panel(interaction)


class ListEditorView(SecureView):
    """Editor de listas (palabras prohibidas, dominios, IDs…) con añadir / quitar / vaciar."""

    def __init__(self, owner_id, guild, cat, key: str, label: str):
        super().__init__(owner_id, guild, cat, timeout=300)
        self.key, self.label = key, label
        self.message = None

    def items(self) -> list:
        return gcfg(self.guild.id, self.cat)[self.key]

    def embed(self) -> discord.Embed:
        items = self.items()
        body = "\n".join(f"`{i + 1}.` `{x}`" for i, x in enumerate(items)) if items else "*— lista vacía —*"
        if len(body) > 3800:
            body = body[:3800] + "\n…"
        e = discord.Embed(title=f"📝 {self.label}", description=body, color=0x8B5CF6)
        e.set_footer(text=f"{len(items)} elemento(s) • Usa los botones para añadir o quitar")
        return e

    async def redraw(self, interaction: discord.Interaction):
        await interaction.response.edit_message(embed=self.embed(), view=self)

    @discord.ui.button(label="Añadir", emoji="➕", style=discord.ButtonStyle.success, row=0)
    async def add(self, interaction: discord.Interaction, button: discord.ui.Button):
        self.message = interaction.message
        await interaction.response.send_modal(ListModal(self, adding=True))

    @discord.ui.button(label="Quitar", emoji="➖", style=discord.ButtonStyle.secondary, row=0)
    async def remove(self, interaction: discord.Interaction, button: discord.ui.Button):
        self.message = interaction.message
        await interaction.response.send_modal(ListModal(self, adding=False))

    @discord.ui.button(label="Vaciar", emoji="🗑️", style=discord.ButtonStyle.danger, row=0)
    async def clear(self, interaction: discord.Interaction, button: discord.ui.Button):
        self.items().clear()
        save_data()
        await self.redraw(interaction)

    @discord.ui.button(label="Volver", emoji="↩️", style=discord.ButtonStyle.primary, row=0)
    async def back(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self.back_to_panel(interaction)


class ListModal(discord.ui.Modal):
    def __init__(self, editor: ListEditorView, adding: bool):
        super().__init__(title=("Añadir a " if adding else "Quitar de ") + editor.label[:30])
        self.editor, self.adding = editor, adding
        self.field = discord.ui.TextInput(
            label="Elementos (separados por coma o salto de línea)", style=discord.TextStyle.paragraph,
            placeholder="palabra1, palabra2, 69" if adding else "Escribe lo que quieres quitar",
            required=True, max_length=1500)
        self.add_item(self.field)

    async def on_submit(self, interaction: discord.Interaction):
        if not (is_allowed(interaction.user.id) and is_authed(interaction.user.id)):
            await interaction.response.send_message("🔒 Sesión expirada. Usa `/acceso`.", ephemeral=True)
            return
        new = [x.strip().lower() for x in re.split(r"[,\n]", self.field.value) if x.strip()]
        items = self.editor.items()
        if self.adding:
            for x in new:
                if x not in items and len(items) < 200:
                    items.append(x)
        else:
            for x in new:
                if x in items:
                    items.remove(x)
        save_data()
        # Modal submissions are a new interaction; edit the original panel message explicitly.
        await interaction.response.defer(ephemeral=True, thinking=True)
        try:
            if self.editor.message is None:
                raise RuntimeError("No se encontró el mensaje original del panel.")
            await self.editor.message.edit(embed=self.editor.embed(), view=self.editor)
            await interaction.followup.send("✅ Lista actualizada.", ephemeral=True)
        except (discord.HTTPException, RuntimeError) as exc:
            await interaction.followup.send(
                f"⚠️ Los datos se guardaron, pero no pude refrescar el panel: {exc}", ephemeral=True)


class EditModal(discord.ui.Modal):
    def __init__(self, view: "PanelView", key: str, label: str, kind: str):
        super().__init__(title="Editar variable")
        self.pview, self.key, self.kind = view, key, kind
        self.message = None
        cur = gcfg(view.guild.id, view.cat)[key]
        default = "" if cur is None else str(cur)
        long_text = kind == "text" and (len(default) > 60 or "msg" in key or key == "welcome")
        self.field = discord.ui.TextInput(
            label=label[:45], default=default[:1000], placeholder=hint_for(kind)[:100],
            style=discord.TextStyle.paragraph if long_text else discord.TextStyle.short,
            required=kind != "text", max_length=1000)
        self.add_item(self.field)

    async def on_submit(self, interaction: discord.Interaction):
        if not (is_allowed(interaction.user.id) and is_authed(interaction.user.id)):
            await interaction.response.send_message("🔒 Sesión expirada. Usa `/acceso`.", ephemeral=True)
            return
        try:
            val = parse_value(interaction.guild, self.kind, self.field.value)
        except ValueError as e:
            await interaction.response.send_message(f"❌ {e}", ephemeral=True)
            return
        gcfg(interaction.guild.id, self.pview.cat)[self.key] = val
        save_data()
        await interaction.response.defer(ephemeral=True, thinking=True)
        try:
            if self.message is None:
                raise RuntimeError("No se encontró el mensaje original del panel.")
            await self.message.edit(
                embed=build_embed(interaction.guild, self.pview.cat),
                view=PanelView(self.pview.owner_id, interaction.guild, self.pview.cat))
            await interaction.followup.send("✅ Opción actualizada.", ephemeral=True)
        except (discord.HTTPException, RuntimeError) as exc:
            await interaction.followup.send(
                f"⚠️ El valor se guardó, pero no pude refrescar el panel: {exc}", ephemeral=True)


class ResetButton(discord.ui.Button):
    def __init__(self):
        super().__init__(label="Restablecer", emoji="♻️", style=discord.ButtonStyle.danger, row=4)

    async def callback(self, interaction: discord.Interaction):
        v = self.view
        data["guilds"].setdefault(str(interaction.guild.id), {})[v.cat] = copy.deepcopy(DEFAULTS[v.cat])
        save_data()
        await interaction.response.edit_message(
            embed=build_embed(interaction.guild, v.cat),
            view=PanelView(v.owner_id, interaction.guild, v.cat))


class RefreshButton(discord.ui.Button):
    def __init__(self):
        super().__init__(label="Refrescar", emoji="🔄", style=discord.ButtonStyle.primary, row=4)

    async def callback(self, interaction: discord.Interaction):
        v = self.view
        await interaction.response.edit_message(
            embed=build_embed(interaction.guild, v.cat),
            view=PanelView(v.owner_id, interaction.guild, v.cat))


class LogoutButton(discord.ui.Button):
    def __init__(self):
        super().__init__(label="Cerrar sesión", emoji="🔒", style=discord.ButtonStyle.secondary, row=4)

    async def callback(self, interaction: discord.Interaction):
        auth_sessions.pop(interaction.user.id, None)
        await interaction.response.edit_message(content="🔒 Sesión cerrada.", embed=None, view=None)


class PanelView(SecureView):
    def __init__(self, owner_id: int, guild: discord.Guild, cat: str):
        super().__init__(owner_id, guild, cat)
        cfg = gcfg(guild.id, cat)
        meta = CATS[cat]
        self.add_item(CategorySelect(cat))
        bools = [v for v in meta["vars"] if v[2] == "bool"][:10]
        for i, (key, label, _) in enumerate(bools):
            self.add_item(ToggleButton(key, label, cfg[key], row=1 + i // 5))
        others = [v for v in meta["vars"] if v[2] != "bool"]
        if others:
            self.add_item(EditSelect(others))
        self.add_item(RefreshButton())
        self.add_item(ResetButton())
        self.add_item(LogoutButton())


class KeyModal(discord.ui.Modal, title="🔑 Acceso al panel"):
    key = discord.ui.TextInput(label="Key de seguridad", placeholder="Escribe tu key", max_length=100)

    async def on_submit(self, interaction: discord.Interaction):
        uid = interaction.user.id
        if not is_allowed(uid):
            await interaction.response.send_message("⛔ No estás autorizado.", ephemeral=True)
            return
        count, locked_until = failed_attempts.get(uid, (0, 0))
        if locked_until > time.time():
            mins = int((locked_until - time.time()) // 60) + 1
            await interaction.response.send_message(f"⛔ Demasiados intentos. Espera {mins} min.", ephemeral=True)
            return
        salt = CONFIG.get("salt")
        stored_hash = CONFIG.get("key_hash")
        if not salt or not stored_hash:
            await interaction.response.send_message(
                "⚠️ La configuración de la key está incompleta. Revisa config.json y vuelve a guardar la key.",
                ephemeral=True)
            return
        given = hash_key(self.key.value.strip(), salt)
        if hmac.compare_digest(given, stored_hash):
            auth_sessions[uid] = time.time() + AUTH_TTL
            failed_attempts.pop(uid, None)
            await interaction.response.send_message(
                "✅ Key correcta. Sesión abierta durante 30 minutos. Ahora ejecuta `/panel`. "
                "Esta key es distinta de la contraseña maestra del token.", ephemeral=True)
        else:
            count += 1
            lock = 0
            if count >= 3:
                lock, count = time.time() + 300, 0
            failed_attempts[uid] = (count, lock)
            await interaction.response.send_message("❌ Key incorrecta.", ephemeral=True)


# =====================================================================
#  DASHBOARD WEB LOCAL (OAuth2 Discord, propietario solamente)
# =====================================================================
DASHBOARD_SETTINGS_FILE = "dashboard_settings.json"
DASHBOARD_HOST = "127.0.0.1"
DASHBOARD_PORT = int(os.getenv("LUMINOS_DASHBOARD_PORT", "8765"))
DASHBOARD_SESSION_SECRET = os.getenv("LUMINOS_DASHBOARD_SESSION_SECRET", "")
DASHBOARD_CLIENT_ID = os.getenv("DISCORD_CLIENT_ID", "")
DASHBOARD_CLIENT_SECRET = os.getenv("DISCORD_CLIENT_SECRET", "")
_dashboard_runner = None


def _dash_settings_load():
    defaults = {"welcome_note": "Luminos Nova", "accent_color": "#8B5CF6", "last_updated": None}
    try:
        with open(DASHBOARD_SETTINGS_FILE, "r", encoding="utf-8") as f:
            saved = json.load(f)
        if isinstance(saved, dict):
            defaults.update({k: saved[k] for k in ("welcome_note", "accent_color", "last_updated") if k in saved})
    except (OSError, ValueError):
        pass
    return defaults


def _dash_settings_save(settings):
    tmp = DASHBOARD_SETTINGS_FILE + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(settings, f, ensure_ascii=False, indent=2)
    os.replace(tmp, DASHBOARD_SETTINGS_FILE)


def _dash_sign(value: str) -> str:
    return hmac.new(DASHBOARD_SESSION_SECRET.encode(), value.encode(), hashlib.sha256).hexdigest()


def _dash_user(request):
    raw = request.cookies.get("ln_session", "")
    try:
        uid, expiry, signature = raw.split(".", 2)
        payload = uid + "." + expiry
        if not hmac.compare_digest(signature, _dash_sign(payload)) or int(expiry) < int(time.time()):
            return None
        if not is_allowed(int(uid)):
            return None
        return {"id": uid}
    except (ValueError, TypeError):
        return None


def _dash_require_owner(request):
    user = _dash_user(request)
    if not user:
        raise web.HTTPUnauthorized(text="Inicia sesión con Discord usando una cuenta autorizada por el dueño del bot.")
    return user


async def _dash_login(request):
    if not DASHBOARD_CLIENT_ID or not DASHBOARD_CLIENT_SECRET or not DASHBOARD_SESSION_SECRET:
        raise web.HTTPServiceUnavailable(text="Falta configurar DISCORD_CLIENT_ID, DISCORD_CLIENT_SECRET y LUMINOS_DASHBOARD_SESSION_SECRET en .env.")
    state = secrets.token_urlsafe(24)
    request.app["oauth_states"][state] = time.time() + 300
    redirect = f"http://127.0.0.1:{DASHBOARD_PORT}/auth/callback"
    url = ("https://discord.com/oauth2/authorize?" +
           __import__('urllib.parse', fromlist=['urlencode']).urlencode({
               "client_id": DASHBOARD_CLIENT_ID, "redirect_uri": redirect,
               "response_type": "code", "scope": "identify", "state": state
           }))
    response = web.HTTPFound(url)
    response.set_cookie("ln_oauth_state", state, httponly=True, samesite="Lax", max_age=300)
    raise response


async def _dash_callback(request):
    if not DASHBOARD_CLIENT_ID or not DASHBOARD_CLIENT_SECRET or not DASHBOARD_SESSION_SECRET:
        raise web.HTTPServiceUnavailable(text="Falta configurar las variables OAuth en .env.")
    state = request.query.get("state", "")
    valid_until = request.app["oauth_states"].pop(state, 0)
    if not state or request.cookies.get("ln_oauth_state") != state or valid_until < time.time():
        raise web.HTTPForbidden(text="Estado OAuth inválido o expirado. Vuelve a iniciar sesión.")
    code = request.query.get("code")
    if not code:
        raise web.HTTPBadRequest(text="Discord no devolvió el código de autorización.")
    redirect = f"http://127.0.0.1:{DASHBOARD_PORT}/auth/callback"
    import urllib.request, urllib.parse
    payload = urllib.parse.urlencode({"client_id": DASHBOARD_CLIENT_ID, "client_secret": DASHBOARD_CLIENT_SECRET,
        "grant_type": "authorization_code", "code": code, "redirect_uri": redirect}).encode()
    req = urllib.request.Request("https://discord.com/api/oauth2/token", data=payload,
        headers={"Content-Type": "application/x-www-form-urlencoded"})
    try:
        with urllib.request.urlopen(req, timeout=10) as res:
            token_data = json.loads(res.read().decode())
        req_user = urllib.request.Request("https://discord.com/api/users/@me",
            headers={"Authorization": "Bearer " + token_data["access_token"]})
        with urllib.request.urlopen(req_user, timeout=10) as res:
            profile = json.loads(res.read().decode())
    except Exception:
        raise web.HTTPBadGateway(text="No se pudo verificar la sesión con Discord. Inténtalo de nuevo.")
    profile_id = str(profile.get("id", ""))
    if not profile_id.isdigit() or not is_allowed(int(profile_id)):
        raise web.HTTPForbidden(text="Acceso denegado: tu cuenta no está autorizada. Pide al dueño que te autorice con /sys_grant.")
    expiry = str(int(time.time()) + 3600)
    payload = profile_id + "." + expiry
    response = web.HTTPFound("/")
    response.set_cookie("ln_session", payload + "." + _dash_sign(payload), httponly=True,
                        samesite="Lax", max_age=3600, secure=False, path="/")
    response.del_cookie("ln_oauth_state", path="/")
    raise response


async def _dash_logout(request):
    response = web.HTTPFound("/")
    response.del_cookie("ln_session", path="/")
    raise response


async def _dash_status(request):
    _dash_require_owner(request)
    return web.json_response({"connected": bot.is_ready(), "bot": str(bot.user) if bot.user else None,
        "latency_ms": round(bot.latency * 1000, 1) if bot.is_ready() else None,
        "guild_count": len(bot.guilds), "owner_id": str(OWNER_ID),
        "guilds": [{"id": str(g.id), "name": g.name, "members": g.member_count or 0,
                    "authorized": guild_is_allowed(g.id)} for g in bot.guilds]})


async def _dash_settings_get(request):
    _dash_require_owner(request)
    return web.json_response(_dash_settings_load())


async def _dash_settings_put(request):
    _dash_require_owner(request)
    if request.content_length and request.content_length > 8192:
        raise web.HTTPRequestEntityTooLarge(max_size=8192, actual_size=request.content_length)
    try:
        body = await request.json()
    except Exception:
        raise web.HTTPBadRequest(text="JSON inválido.")
    note = str(body.get("welcome_note", "Luminos Nova")).strip()[:120]
    color = str(body.get("accent_color", "#8B5CF6")).strip()
    if not re.fullmatch(r"#[0-9a-fA-F]{6}", color):
        raise web.HTTPBadRequest(text="El color debe tener formato #RRGGBB.")
    settings = {"welcome_note": note, "accent_color": color, "last_updated": int(time.time())}
    _dash_settings_save(settings)
    return web.json_response({"ok": True, **settings})


async def _dash_send_embed(request):
    _dash_require_owner(request)
    try:
        body = await request.json()
        guild_id = int(body.get("guild_id", 0)); channel_id = int(body.get("channel_id", 0))
        title = str(body.get("title", "Luminos Nova"))[:256]
        description = str(body.get("description", ""))[:4000]
        raw_color = str(body.get("color", "#8B5CF6"))
        if not re.fullmatch(r"#[0-9a-fA-F]{6}", raw_color): raise ValueError("Color inválido; usa #RRGGBB.")
        if not description.strip(): raise ValueError("La descripción no puede estar vacía.")
    except (ValueError, TypeError) as exc:
        raise web.HTTPBadRequest(text=str(exc))
    guild = bot.get_guild(guild_id)
    if not guild or not guild_is_allowed(guild_id): raise web.HTTPForbidden(text="Servidor no encontrado o no autorizado en ALLOWED_GUILD_IDS.")
    channel = guild.get_channel(channel_id)
    if not isinstance(channel, (discord.TextChannel, discord.Thread)):
        raise web.HTTPBadRequest(text="Selecciona un canal de texto válido del servidor autorizado.")
    me = guild.me
    if not me or not channel.permissions_for(me).send_messages or not channel.permissions_for(me).embed_links:
        raise web.HTTPForbidden(text="Al bot le faltan permisos para enviar mensajes o embeds en ese canal.")
    embed = discord.Embed(title=title or None, description=description, color=int(raw_color[1:], 16))
    try:
        msg = await channel.send(embed=embed)
    except discord.HTTPException:
        raise web.HTTPBadGateway(text="Discord no pudo enviar el embed.")
    return web.json_response({"ok": True, "message_id": str(msg.id), "channel": channel.name})


async def start_local_dashboard():
    global _dashboard_runner
    app = web.Application(client_max_size=8192)
    app["oauth_states"] = {}
    app.router.add_get("/auth/login", _dash_login)
    app.router.add_get("/auth/callback", _dash_callback)
    app.router.add_get("/auth/logout", _dash_logout)
    app.router.add_get("/api/status", _dash_status)
    app.router.add_get("/api/settings", _dash_settings_get)
    app.router.add_put("/api/settings", _dash_settings_put)
    app.router.add_post("/api/send-embed", _dash_send_embed)
    async def dashboard_page(request):
        return web.FileResponse(os.path.join(os.path.dirname(__file__), "dashboard", "index.html"))
    app.router.add_get("/", dashboard_page)
    _dashboard_runner = web.AppRunner(app)
    await _dashboard_runner.setup()
    site = web.TCPSite(_dashboard_runner, DASHBOARD_HOST, DASHBOARD_PORT)
    try:
        await site.start()
        print(f"🌐 Dashboard local preparado: http://{DASHBOARD_HOST}:{DASHBOARD_PORT}")
    except OSError as exc:
        print(f"⚠️ Dashboard no pudo iniciar en el puerto {DASHBOARD_PORT}: {exc}")

# =====================================================================
#  BOT
# =====================================================================
intents = discord.Intents.default()
intents.members = True           # activar "Server Members Intent" en el Developer Portal
intents.message_content = True   # activar "Message Content Intent" en el Developer Portal

bot = commands.Bot(command_prefix=commands.when_mentioned, intents=intents)


async def _allowed_guild_interaction(interaction: discord.Interaction) -> bool:
    # Bloquea comandos en DM y en servidores que no estén en la lista blanca.
    if guild_is_allowed(interaction.guild_id):
        return True
    try:
        if not interaction.response.is_done():
            await interaction.response.send_message(
                "🔒 Luminos Nova está en mantenimiento o no está habilitado en este servidor.", ephemeral=True
            )
    except discord.HTTPException:
        pass
    return False


bot.tree.interaction_check = _allowed_guild_interaction

invite_cache: dict[int, dict] = {}
join_times: dict[int, deque] = defaultdict(deque)
raid_until: dict[int, float] = {}          # modo raid automático
manual_lock_until: dict[int, float] = {}   # bloqueo manual con /sys_raid
spam_tracker: dict[tuple, deque] = defaultdict(deque)
_commands_ready = False


async def cache_invites(guild: discord.Guild):
    try:
        invs = await guild.invites()
        invite_cache[guild.id] = {i.code: (i.uses or 0, i.inviter.id if i.inviter else None) for i in invs}
    except (discord.Forbidden, discord.HTTPException):
        pass


async def sync_guild(guild: discord.Guild):
    """Sincroniza los comandos SOLO en servidores autorizados (evita comandos duplicados)."""
    try:
        guild_obj = discord.Object(id=guild.id)
        bot.tree.copy_global_to(guild=guild_obj)
        synced = await bot.tree.sync(guild=guild_obj)
        print(f"⚡ {guild.name} ({guild.id}): {len(synced)} comandos sincronizados")
    except discord.HTTPException as exc:
        print(f"⚠️ No se pudieron sincronizar comandos en {guild.id}: {exc}")


@bot.event
async def setup_hook():
    bot.add_view(GiveawayView())
    bot.add_view(TicketOpenView())
    bot.add_view(TicketCloseView())
    autosave.start()
    giveaway_loop.start()
    # Dashboard web local: solo escucha en 127.0.0.1, nunca expuesto a Internet.
    await start_local_dashboard()


@bot.event
async def on_ready():
    global _commands_ready
    print(f"✅ Conectado como {bot.user} (ID: {bot.user.id})")
    await bot.change_presence(activity=discord.Game("Luminos Nova • /panel"))
    for g in bot.guilds:
        if not guild_is_allowed(g.id):
            print(f"🔒 {g.name} ({g.id}): fuera de la lista autorizada; inactivo")
            continue
        await cache_invites(g)
        if not _commands_ready:
            await sync_guild(g)
    if not _commands_ready:
        _commands_ready = True
        # Limpia los comandos GLOBALES antiguos en Discord (causaban comandos duplicados).
        try:
            saved = list(bot.tree.get_commands())
            bot.tree.clear_commands(guild=None)
            await bot.tree.sync()
            for c in saved:
                bot.tree.add_command(c)
            print("🧹 Comandos globales antiguos eliminados (ya no hay duplicados).")
        except Exception as exc:  # noqa: BLE001
            print(f"⚠️ No se pudieron limpiar los comandos globales: {exc}")


@bot.event
async def on_guild_join(guild: discord.Guild):
    if not guild_is_allowed(guild.id):
        print(f"🔒 Unido a {guild.id}, pero queda inactivo: no está autorizado")
        return
    await cache_invites(guild)
    await sync_guild(guild)


@bot.tree.error
async def on_app_command_error(interaction: discord.Interaction, error: app_commands.AppCommandError):
    if isinstance(error, NotAllowed):
        msg = "⛔ No estás autorizado para usar esto."
    elif isinstance(error, NotOwner):
        msg = "⛔ Solo el dueño del bot puede hacer esto."
    elif isinstance(error, NotAuthed):
        msg = "🔒 Necesitas autenticarte con `/acceso` (key de seguridad)."
    elif isinstance(error, app_commands.MissingPermissions):
        msg = "❌ No tienes los permisos necesarios."
    elif isinstance(error, app_commands.BotMissingPermissions):
        msg = "❌ Al bot le faltan permisos para hacer eso."
    elif isinstance(error, app_commands.NoPrivateMessage):
        msg = "❌ Este comando solo funciona en servidores."
    else:
        print("Error en comando:", repr(error))
        msg = f"⚠️ Ocurrió un error: {error}"
    try:
        if interaction.response.is_done():
            await interaction.followup.send(msg, ephemeral=True)
        else:
            await interaction.response.send_message(msg, ephemeral=True)
    except discord.HTTPException:
        pass


# ---------- Utilidades ----------
async def send_log(guild: discord.Guild, embed: discord.Embed, kind: str):
    cfg = gcfg(guild.id, "logs")
    if not cfg["enabled"] or not cfg.get(kind, True) or not cfg["channel"]:
        return
    ch = guild.get_channel(cfg["channel"])
    if ch:
        try:
            await ch.send(embed=embed)
        except discord.HTTPException:
            pass


async def punish(guild: discord.Guild, member: discord.Member, action: str, reason: str, dm: bool = False):
    if dm:
        ar = gcfg(guild.id, "antiraid")
        ctx = variable_values(user=member, guild=guild, extra={"{reason}": reason, "{action}": action})
        if not await send_saved(member, guild.id, ar.get("dm_embed"), ctx):
            try:
                await member.send(f"🛡️ Fuiste sancionado automáticamente en **{guild.name}**: {reason}")
            except discord.HTTPException:
                pass
    try:
        if action == "ban":
            await guild.ban(member, reason=reason)
        elif action == "timeout":
            await member.timeout(timedelta(hours=1), reason=reason)
        else:
            await guild.kick(member, reason=reason)
    except discord.HTTPException as e:
        print(f"No pude sancionar a {member.id}: {e}")


def resolve_user_id(guild: discord.Guild, target: str):
    cleaned = target.strip().replace("<@", "").replace("!", "").replace(">", "")
    if cleaned.isdigit():
        return int(cleaned)
    member = guild.get_member_named(cleaned)
    if member is None:
        member = discord.utils.find(
            lambda m: m.display_name.lower() == cleaned.lower() or m.name.lower() == cleaned.lower(),
            guild.members)
    return member.id if member else None


# =====================================================================
#  TEXTO: normalización y detección (palabras prohibidas, enlaces)
# =====================================================================
_LEET = str.maketrans({"0": "o", "1": "i", "3": "e", "4": "a", "5": "s", "7": "t", "@": "a", "$": "s", "!": "i"})
_ZERO_WIDTH = dict.fromkeys(map(ord, "\u200b\u200c\u200d\u2060\ufeff"), None)


def normalize_text(text: str, strict: bool) -> str:
    t = unicodedata.normalize("NFKD", text.lower())
    t = "".join(c for c in t if not unicodedata.combining(c)).translate(_ZERO_WIDTH)
    return t.translate(_LEET) if strict else t


def _spaced(t: str) -> str:
    return re.sub(r"[^a-z0-9]+", " ", t).strip()


def _collapse(t: str) -> str:
    return re.sub(r"([a-z])\1+", r"\1", t)


def _compact(t: str) -> str:
    return re.sub(r"[^a-z0-9]+", "", t)


def find_badword(text: str, words: list, mode: str = "smart", strict: bool = True) -> Optional[str]:
    """Devuelve la palabra prohibida encontrada (o None).
    smart    → palabras con números se buscan DENTRO del texto (ds69, 69manzanas, 969);
               las demás solo como palabra completa (evita 'disputa' por 'puta').
    word     → siempre palabra completa.
    contains → siempre dentro del texto (más agresivo, también detecta p.u.t.o)."""
    norm = normalize_text(text, strict)
    spaced = _spaced(norm)
    if strict:
        spaced = _collapse(spaced)
    compact_text = _compact(norm)
    if strict:
        compact_text = _collapse(compact_text)
    for raw in words:
        w = _spaced(normalize_text(str(raw), strict))
        if strict:
            w = _collapse(w)
        if not w:
            continue
        has_digit = any(c.isdigit() for c in str(raw))
        use_contains = mode == "contains" or (mode == "smart" and has_digit)
        if use_contains:
            if w in spaced:
                return str(raw)
            cw = _compact(w)
            if mode == "contains" and len(cw) >= 3 and cw in compact_text:
                return str(raw)
        else:
            if re.search(rf"(?<![a-z0-9]){re.escape(w)}(?![a-z0-9])", spaced):
                return str(raw)
    return None


URL_FIND = re.compile(
    r"(?:https?://|www\.)[^\s<>]+|(?:discord\.gg|discord(?:app)?\.com/invite)/[^\s<>]+", re.I)


def has_blocked_link(content: str, whitelist: list) -> bool:
    allowed = [d.lower().strip().removeprefix("https://").removeprefix("http://").removeprefix("www.").strip("/")
               for d in whitelist if d]
    for m in URL_FIND.finditer(content):
        url = m.group(0).lower()
        host = re.sub(r"^https?://", "", url).removeprefix("www.")
        host = re.split(r"[/?#:]", host, maxsplit=1)[0]
        if not any(host == d or host.endswith("." + d) for d in allowed):
            return True
    return False


# =====================================================================
#  ANTIRAID
# =====================================================================
async def raid_alert(guild: discord.Guild, embed: discord.Embed):
    ar = gcfg(guild.id, "antiraid")
    ch = guild.get_channel(ar["alert_channel"]) if ar["alert_channel"] else None
    if ch:
        try:
            await ch.send(embed=embed)
            return
        except discord.HTTPException:
            pass
    await send_log(guild, embed, "log_mod")


async def handle_antiraid(member: discord.Member) -> bool:
    """Devuelve True si el miembro fue sancionado (y por tanto se detiene el resto del proceso)."""
    guild = member.guild
    ar = gcfg(guild.id, "antiraid")
    now = time.time()
    action = ar["action"]
    reason = None

    # Bloqueo manual (/sys_raid): nadie entra mientras dure (salvo bots permitidos)
    if manual_lock_until.get(guild.id, 0) > now and str(member.id) not in ar["bot_whitelist"]:
        reason = "Antiraid: bloqueo manual de entradas activo"
    elif ar["enabled"]:
        if member.bot:
            if str(member.id) in ar["bot_whitelist"]:
                return False
            if ar["block_bots"]:
                reason = "Antiraid: bots no permitidos"
        else:
            dq = join_times[guild.id]
            dq.append((now, member.id))
            window = max(1, ar["join_window"])
            while dq and now - dq[0][0] > window:
                dq.popleft()

            if ar["min_age"] > 0 and (discord.utils.utcnow() - member.created_at).days < ar["min_age"]:
                reason = f"Antiraid: cuenta con menos de {ar['min_age']} días"
            elif ar["no_avatar"] and member.avatar is None:
                reason = "Antiraid: cuenta sin avatar"
            elif ar["name_filter"] and find_badword(
                    f"{member.name} {member.display_name}", ar["name_filter"], "contains", True):
                reason = "Antiraid: nombre de usuario prohibido"
            elif ar["join_limit"] > 0:
                if len(dq) >= ar["join_limit"] and raid_until.get(guild.id, 0) < now:
                    raid_until[guild.id] = now + max(10, ar["lockdown_secs"])
                    reason = "Antiraid: oleada de entradas"
                    victims = 0
                    for _, mid in list(dq)[:-1]:
                        other = guild.get_member(mid)
                        if other:
                            await punish(guild, other, action, reason, ar["dm_notify"])
                            victims += 1
                    e = discord.Embed(
                        title="🚨 RAID DETECTADO",
                        description=(f"{len(dq)} entradas en {window}s.\n"
                                     f"Modo raid activo **{max(10, ar['lockdown_secs'])}s**; "
                                     f"se sancionaron {victims + 1} cuentas (`{action}`)."),
                        color=0xE74C3C)
                    await raid_alert(guild, e)
                elif raid_until.get(guild.id, 0) > now:
                    reason = "Antiraid: oleada de entradas"

    if not reason:
        return False
    await punish(guild, member, action, reason, ar["dm_notify"])
    e = discord.Embed(title="🛡️ Antiraid", description=f"{member} (`{member.id}`)\n{reason}\nAcción: `{action}`",
                      color=0xE74C3C)
    await send_log(guild, e, "log_mod")
    return True


# =====================================================================
#  EVENTOS: entradas / salidas (lista negra, antiraid, invites, logs)
# =====================================================================
@bot.event
async def on_member_join(member: discord.Member):
    guild = member.guild
    if not guild_is_allowed(guild.id):
        return

    # 1) Lista negra: ban instantáneo (personas y bots)
    entries = data["blacklist"].get(str(guild.id), {})
    if str(member.id) in entries:
        await punish(guild, member, "ban", f"Lista negra: {entries[str(member.id)]}")
        return

    # 2) Antiraid
    if await handle_antiraid(member):
        return

    # 2.5) Bienvenida + autorol
    await handle_welcome(member)

    # 3) Invite tracker
    inv = gcfg(guild.id, "invites")
    if inv["enabled"]:
        await track_invite(member, inv)

    # 4) Logs
    e = discord.Embed(title="📥 Miembro entró", color=0x2ECC71,
                      description=f"{member.mention} (`{member.id}`)")
    e.add_field(name="Cuenta creada", value=discord.utils.format_dt(member.created_at, "R"))
    await send_log(guild, e, "log_members")


async def track_invite(member: discord.Member, cfg: dict):
    guild = member.guild
    old = invite_cache.get(guild.id, {})
    try:
        invs = await guild.invites()
    except (discord.Forbidden, discord.HTTPException):
        return
    new = {i.code: (i.uses or 0, i.inviter.id if i.inviter else None) for i in invs}
    inviter_id, code = None, None
    for c, (uses, inviter) in new.items():
        if uses > old.get(c, (0, None))[0]:
            inviter_id, code = inviter, c
            break
    if inviter_id is None:
        missing = [c for c in old if c not in new]
        if len(missing) == 1:  # invitación de un solo uso que se agotó
            inviter_id, code = old[missing[0]][1], missing[0]
    invite_cache[guild.id] = new

    store = data["invites"].setdefault(str(guild.id), {"stats": {}, "by": {}})
    if inviter_id:
        st = store["stats"].setdefault(str(inviter_id), {"joins": 0, "left": 0})
        st["joins"] += 1
        store["by"][str(member.id)] = inviter_id
        save_data()

    if cfg["announce"] and cfg["channel"]:
        ch = guild.get_channel(cfg["channel"])
        if ch:
            inviter = guild.get_member(inviter_id) if inviter_id else None
            st_ = store["stats"].get(str(inviter_id), {"joins": 0, "left": 0}) if inviter_id else {"joins": 0, "left": 0}
            ctx = variable_values(user=member, guild=guild, channel=ch, extra={
                "{inviter}": inviter.display_name if inviter else "desconocido",
                "{inviter_mention}": f"<@{inviter_id}>" if inviter_id else "*desconocido*",
                "{inviter_avatar}": str(inviter.display_avatar.url) if inviter else "",
                "{invites}": st_["joins"] - st_["left"]})
            if await send_saved(ch, guild.id, cfg.get("join_embed"), ctx):
                return
            who = f"<@{inviter_id}>" if inviter_id else "*desconocido*"
            e = discord.Embed(color=0x3498DB, title="📨 Nuevo miembro",
                              description=f"{member.mention} entró invitado por {who}")
            try:
                await ch.send(embed=e)
            except discord.HTTPException:
                pass


@bot.event
async def on_member_remove(member: discord.Member):
    guild = member.guild
    if not guild_is_allowed(guild.id):
        return
    store = data["invites"].get(str(guild.id))
    if store:
        inviter = store["by"].pop(str(member.id), None)
        if inviter and str(inviter) in store["stats"]:
            store["stats"][str(inviter)]["left"] += 1
            mark_dirty()
    e = discord.Embed(title="📤 Miembro salió", color=0xE67E22,
                      description=f"{member} (`{member.id}`)")
    await send_log(guild, e, "log_members")
    await handle_goodbye(member)


@bot.event
async def on_invite_create(invite: discord.Invite):
    if invite.guild:
        invite_cache.setdefault(invite.guild.id, {})[invite.code] = (
            invite.uses or 0, invite.inviter.id if invite.inviter else None)


@bot.event
async def on_member_ban(guild: discord.Guild, user: discord.User):
    if not guild_is_allowed(guild.id):
        return
    e = discord.Embed(title="🔨 Usuario baneado", color=0xC0392B, description=f"{user} (`{user.id}`)")
    await send_log(guild, e, "log_mod")


@bot.event
async def on_member_unban(guild: discord.Guild, user: discord.User):
    """Si alguien de la lista negra es desbaneado a mano, se vuelve a banear."""
    if not guild_is_allowed(guild.id):
        return
    entries = data["blacklist"].get(str(guild.id), {})
    if str(user.id) in entries:
        try:
            await guild.ban(discord.Object(id=user.id), reason=f"Lista negra: {entries[str(user.id)]}")
        except discord.HTTPException as e:
            print(f"No pude rebanear a {user.id}: {e}")


# =====================================================================
#  EVENTOS: mensajes (protección, niveles, logs)
# =====================================================================
async def handle_protection(message: discord.Message, edited: bool = False) -> bool:
    """Aplica los filtros de Seguridad. Devuelve True si el mensaje fue eliminado."""
    pr = gcfg(message.guild.id, "proteccion")
    active = (pr["antilinks"] or pr["antispam"] or pr["badwords_on"] or pr["anticaps"]
              or pr["mention_limit"] > 0)
    if not active:
        return False
    if edited and not pr["check_edits"]:
        return False
    member = message.author
    if not isinstance(member, discord.Member):
        return False
    perms = member.guild_permissions
    if pr["exempt_staff"] and (perms.administrator or perms.manage_messages):
        return False
    if pr["bypass_role"] and any(r.id == pr["bypass_role"] for r in member.roles):
        return False

    content = message.content or ""
    reason, is_spam = None, False

    if pr["badwords_on"] and pr["badwords"] and find_badword(
            content, pr["badwords"], pr["badwords_mode"], pr["strict"]):
        reason = "palabra prohibida"
    elif pr["antilinks"] and has_blocked_link(content, pr["link_whitelist"]):
        reason = "enlaces no permitidos"
    elif pr["mention_limit"] > 0 and (
            len({m.id for m in message.mentions}) + len(message.role_mentions)
            + (10 if message.mention_everyone else 0)) > pr["mention_limit"]:
        reason = "demasiadas menciones"
    elif pr["anticaps"]:
        letters = [c for c in content if c.isalpha()]
        if len(letters) >= 10 and 100 * sum(c.isupper() for c in letters) / len(letters) >= pr["caps_percent"]:
            reason = "exceso de mayúsculas"
    if not reason and pr["antispam"] and pr["spam_limit"] > 0 and not edited:
        dq = spam_tracker[(message.guild.id, member.id)]
        now = time.time()
        dq.append(now)
        while dq and now - dq[0] > max(1, pr["spam_window"]):
            dq.popleft()
        if len(dq) >= pr["spam_limit"]:
            reason, is_spam = "spam", True
            dq.clear()

    if not reason:
        return False
    try:
        await message.delete()
    except discord.HTTPException:
        pass
    if pr["notify"]:
        ctx = variable_values(user=member, guild=message.guild, channel=message.channel,
                              extra={"{reason}": reason})
        if not await send_saved(message.channel, message.guild.id, pr.get("warn_embed"), ctx,
                                content=member.mention, delete_after=8):
            try:
                await message.channel.send(f"⚠️ {member.mention}, {reason}.", delete_after=5)
            except discord.HTTPException:
                pass
    if is_spam and pr["timeout_min"] > 0:
        try:
            await member.timeout(timedelta(minutes=pr["timeout_min"]), reason="Antispam")
        except discord.HTTPException:
            pass
    e = discord.Embed(title="🔐 Seguridad", color=0x9B59B6,
                      description=f"{member.mention} (`{member.id}`) en {message.channel.mention}\n"
                                  f"**Motivo:** {reason}")
    if content:
        e.add_field(name="Mensaje", value=content[:1000], inline=False)
    await send_log(message.guild, e, "log_mod")
    return True


def eco(guild_id: int, user_id: int) -> dict:
    return data["economy"].setdefault(str(guild_id), {}).setdefault(
        str(user_id), {"coins": 0, "xp": 0, "level": 0, "last_daily": 0, "last_work": 0, "last_xp": 0})


@bot.event
async def on_message(message: discord.Message):
    if message.author.bot or not message.guild:
        return
    if not guild_is_allowed(message.guild.id):
        return
    if await handle_protection(message):
        return

    dv = gcfg(message.guild.id, "diversion")
    if dv["enabled"] and dv["levels"]:
        u = eco(message.guild.id, message.author.id)
        now = time.time()
        if now - u["last_xp"] >= 60:
            u["last_xp"] = now
            u["xp"] += random.randint(10, 20)
            need = 5 * u["level"] ** 2 + 50 * u["level"] + 100
            if u["xp"] >= need:
                u["xp"] -= need
                u["level"] += 1
                ch = message.guild.get_channel(dv["level_channel"]) if dv["level_channel"] else message.channel
                if dv.get("level_messages", False):
                    dest = ch or message.channel
                    ctx = variable_values(user=message.author, guild=message.guild, channel=dest,
                                          extra={"{level}": u["level"]})
                    if not await send_saved(dest, message.guild.id, dv.get("level_embed"), ctx,
                                            content=message.author.mention):
                        try:
                            await dest.send(f"🎉 {message.author.mention} subió al **nivel {u['level']}**!")
                        except discord.HTTPException:
                            pass
            mark_dirty()


@bot.event
async def on_message_delete(message: discord.Message):
    if not message.guild or message.author.bot or not guild_is_allowed(message.guild.id):
        return
    e = discord.Embed(title="🗑️ Mensaje eliminado", color=0xE74C3C,
                      description=message.content[:1500] or "*sin texto*")
    e.add_field(name="Autor", value=f"{message.author.mention} (`{message.author.id}`)")
    e.add_field(name="Canal", value=message.channel.mention)
    e.set_footer(text=f"ID mensaje: {message.id}")
    await send_log(message.guild, e, "log_messages")


@bot.event
async def on_message_edit(before: discord.Message, after: discord.Message):
    if not after.guild or after.author.bot or before.content == after.content or not guild_is_allowed(after.guild.id):
        return
    # Los filtros también revisan los mensajes editados (así no se evaden editando).
    if await handle_protection(after, edited=True):
        return
    e = discord.Embed(title="✏️ Mensaje editado", color=0xF39C12, url=after.jump_url)
    e.add_field(name="Antes", value=before.content[:1000] or "—", inline=False)
    e.add_field(name="Después", value=after.content[:1000] or "—", inline=False)
    e.add_field(name="Autor", value=f"{after.author.mention} (`{after.author.id}`)")
    e.add_field(name="Canal", value=after.channel.mention)
    await send_log(after.guild, e, "log_messages")


# =====================================================================
#  COMANDOS: acceso, panel, ayuda
# =====================================================================
@bot.tree.command(name="acceso", description="🔑 Introduce tu key de seguridad para desbloquear el panel")
@app_commands.guild_only()
@requires_allowed()
async def acceso(interaction: discord.Interaction):
    await interaction.response.send_modal(KeyModal())


@bot.tree.command(name="panel", description="🎛️ Abre el panel de control del bot")
@app_commands.guild_only()
@requires_key()
async def panel(interaction: discord.Interaction):
    await interaction.response.send_message(
        embed=build_embed(interaction.guild, "antiraid"),
        view=PanelView(interaction.user.id, interaction.guild, "antiraid"),
        ephemeral=True)


@bot.tree.command(name="ayuda", description="📖 Lista de comandos disponibles")
@app_commands.guild_only()
@requires_key()
async def ayuda(interaction: discord.Interaction):
    groups = {
        "🔐 Acceso y panel": {"acceso", "panel", "ayuda"},
        "🛡️ Seguridad y moderación": {"sys_lock", "sys_unlock", "sys_records", "sys_raid", "sys_sweep",
                                      "sys_remove", "sys_timeout"},
        "🎉 Eventos y sorteos": {"event_start", "event_end", "event_reroll"},
        "🎫 Tickets y soporte": {"sys_support", "ticket_add"},
        "🧰 Utilidades y administración": {"sys_time", "sys_user", "sys_server", "sys_ping", "embed",
            "embed_send", "embed_list", "embed_delete",
            "canal_nombre", "canal_mover", "canal_emoji", "rol_nombre", "rol_color", "rol_orden", "variables"},
        "📨 Comunidad": {"invite_stats", "invite_rank", "ally_add", "ally_list", "ally_remove"},
        "🎮 Economía, niveles y diversión": {"wallet", "claim", "shift", "wager", "transfer", "wealth", "level",
                                             "oracle", "coinflip", "hug", "pfp"},
        "👑 Gestión de acceso": {"sys_grant", "sys_revoke", "sys_accesslist"},
    }
    registered = {cmd.name: cmd for cmd in bot.tree.get_commands()}
    e = discord.Embed(
        title="✨ LUMINOS NOVA • Centro de ayuda",
        description=("Los comandos privados requieren autorización y key.\n"
                     "Usa `/variables` para consultar todos los marcadores de texto disponibles.\n\n"
                     "👥 **Para dar acceso a alguien:** el dueño ejecuta `/sys_grant`; después esa persona usa "
                     "`/acceso` e introduce la key de seguridad.\n"
                     "🌐 El bot solo funciona en los servidores configurados en `ALLOWED_GUILD_IDS`."),
        color=0x8B5CF6)
    for title, names in groups.items():
        lines = [f"• `/{name}` — {registered[name].description}" for name in sorted(names) if name in registered]
        if lines:
            e.add_field(name=title, value="\n".join(lines)[:1024], inline=False)
    e.add_field(name="💡 Consejo", value="Casi todo se configura desde `/panel`: antiraid, seguridad, logs, tickets…",
                inline=False)
    e.set_footer(text="Luminos Nova • Panel seguro")
    await interaction.response.send_message(embed=e, ephemeral=True)


VARIABLE_GROUPS = [
    ("👤 Persona", 0x8B5CF6, [
        ("{user} / {mention}", "Mención de la persona."),
        ("{username}", "Nombre de usuario."),
        ("{displayname}", "Apodo / nombre visible en el servidor."),
        ("{id}", "ID de la persona."),
        ("{user_avatar} / {avatar}", "URL del avatar (para imagen o miniatura)."),
        ("{created_at}", "Fecha de creación de la cuenta."),
        ("{joined_at}", "Fecha de entrada al servidor (si existe)."),
    ]),
    ("🏠 Servidor, canal y fecha", 0x5865F2, [
        ("{server}", "Nombre del servidor."),
        ("{server_id}", "ID del servidor."),
        ("{count}", "Cantidad de miembros."),
        ("{server_icon}", "URL del icono del servidor."),
        ("{server_banner}", "URL del banner (si tiene)."),
        ("{channel}", "Mención del canal actual."),
        ("{channel_name}", "Nombre del canal."),
        ("{channel_id}", "ID del canal."),
        ("{date}", "Fecha actual (dd/mm/aaaa)."),
        ("{time}", "Hora actual UTC."),
    ]),
    ("🤝 Alianzas", 0x16A085, [
        ("{representative} / {rep}", "Nombre del representante."),
        ("{representative_mention} / {rep_mention}", "Mención del representante."),
        ("{representative_avatar} / {rep_avatar}", "Avatar del representante."),
        ("{inviter} / {registered_by}", "Quien registró la alianza."),
        ("{inviter_mention} / {registered_by_mention}", "Mención de quien la registró."),
        ("{inviter_avatar} / {registered_by_avatar}", "Avatar de quien la registró."),
        ("{alliance_name}", "Nombre de la alianza."),
        ("{alliance_invite}", "Enlace de invitación."),
        ("{alliance_description}", "Descripción."),
    ]),
    ("🎯 Según la función", 0xF1C40F, [
        ("{prize} · {winners} · {host} · {host_mention}", "Sorteos: premio, ganadores, organizador."),
        ("{level}", "Subida de nivel."),
        ("{reason} · {action}", "Antiraid (DM) y avisos de Seguridad: motivo y acción."),
        ("{ticket}", "Tickets: número del ticket."),
        ("{inviter} · {inviter_mention} · {inviter_avatar} · {invites}",
         "Invites: quién invitó y cuántas invitaciones activas tiene."),
    ]),
]


def variables_embeds() -> list:
    embeds = []
    for i, (title, color, items) in enumerate(VARIABLE_GROUPS):
        body = "\n".join(f"`{tok}` — {desc}" for tok, desc in items)
        if i == 0:
            body = ("Escribe estas variables tal cual; el bot las reemplaza al enviar.\n"
                    "Funcionan en `/embed`, **embeds guardados** y mensajes de bienvenida/despedida.\n"
                    "Ejemplo: `¡Hola {user}! Somos {count} en {server}.`\n\n") + body
        embeds.append(discord.Embed(title=title, description=body, color=color))
    return embeds


@bot.tree.command(name="variables", description="📚 Muestra todas las variables disponibles para textos y embeds")
@app_commands.guild_only()
@requires_key()
async def variables_cmd(interaction: discord.Interaction):
    await interaction.response.send_message(embeds=variables_embeds(), ephemeral=True)


def extract_id(token: str) -> Optional[int]:
    nums = re.findall(r"\d{17,20}", token)
    return int(nums[-1]) if nums else None  # en un enlace, el último número es el mensaje


def fmt_delta(delta: timedelta) -> str:
    total_ms = delta // timedelta(milliseconds=1)
    days, rem = divmod(total_ms, 86_400_000)
    hours, rem = divmod(rem, 3_600_000)
    mins, rem = divmod(rem, 60_000)
    secs, ms = divmod(rem, 1000)
    parts = []
    if days:
        parts.append(f"{days}d")
    if hours:
        parts.append(f"{hours}h")
    if mins:
        parts.append(f"{mins}m")
    parts.append(f"{secs}s")
    parts.append(f"{ms:03d}ms")
    return " ".join(parts)


def fmt_exact(dt) -> str:
    return dt.strftime("%Y-%m-%d %H:%M:%S.") + f"{dt.microsecond // 1000:03d} UTC"


@bot.tree.command(name="sys_time", description="⏱️ Tiempo entre mensajes usando sus IDs o enlaces")
@app_commands.describe(mensajes="Uno o más IDs/enlaces separados por espacios. Con uno solo mide hasta ahora.")
@requires_key()
async def tiempo(interaction: discord.Interaction, mensajes: str):
    tokens = [t for t in re.split(r"[\s,;]+", mensajes.strip()) if t]
    ids = [extract_id(t) for t in tokens]
    if not ids or any(i is None for i in ids):
        await interaction.response.send_message(
            "❌ Pon IDs de mensajes válidos (activa el modo desarrollador → clic derecho → Copiar ID).",
            ephemeral=True)
        return
    if len(ids) > 25:
        await interaction.response.send_message("❌ Máximo 25 mensajes.", ephemeral=True)
        return

    times = [(i, discord.utils.snowflake_time(i)) for i in ids]
    if len(times) == 1:
        times.append((0, discord.utils.utcnow()))
    times.sort(key=lambda x: x[1])

    e = discord.Embed(title="⏱️ Tiempo entre mensajes", color=0x1ABC9C)
    lines = []
    for n, (mid, t) in enumerate(times, start=1):
        label = f"`{mid}`" if mid else "**ahora**"
        lines.append(f"**{n}.** {label} → `{fmt_exact(t)}`")
    e.add_field(name="📌 Momentos", value="\n".join(lines)[:1024], inline=False)

    gaps = []
    for a, b in zip(times, times[1:]):
        d = b[1] - a[1]
        gaps.append(f"{a[0] or 'ahora'} ➜ {b[0] or 'ahora'}: **{fmt_delta(d)}** "
                    f"({d.total_seconds():.3f} s)")
    e.add_field(name="↔️ Entre cada mensaje", value="\n".join(gaps)[:1024], inline=False)

    total = times[-1][1] - times[0][1]
    e.add_field(name="📏 Total", value=f"**{fmt_delta(total)}** ({total.total_seconds():.3f} s)", inline=False)
    await interaction.response.send_message(embed=e)


# =====================================================================
#  LISTA NEGRA + MODO RAID MANUAL
# =====================================================================
@bot.tree.command(name="sys_lock", description="🔨 Banea y añade a la lista negra (ID, mención o username)")
@app_commands.describe(objetivo="ID, mención o username", razon="Motivo del ban")
@app_commands.guild_only()
@app_commands.checks.has_permissions(ban_members=True)
@requires_key()
async def permaban(interaction: discord.Interaction, objetivo: str, razon: str = "Sin razón"):
    await interaction.response.defer(ephemeral=True)
    guild = interaction.guild
    uid = resolve_user_id(guild, objetivo)
    if uid is None:
        await interaction.followup.send("No encontré a ese usuario. Si no está en el servidor, usa su **ID**.",
                                        ephemeral=True)
        return
    if uid in (interaction.user.id, bot.user.id):
        await interaction.followup.send("No puedes banearte a ti ni al bot.", ephemeral=True)
        return

    data["blacklist"].setdefault(str(guild.id), {})[str(uid)] = razon
    save_data()
    try:
        await guild.ban(discord.Object(id=uid), reason=f"{razon} (por {interaction.user})")
        await interaction.followup.send(f"✅ `{uid}` baneado y añadido a la lista negra.", ephemeral=True)
    except discord.Forbidden:
        await interaction.followup.send(
            "❌ No tengo permisos o su rol es superior al mío. Sube mi rol y activa 'Banear miembros'.",
            ephemeral=True)
    except discord.HTTPException as e:
        await interaction.followup.send(f"❌ Error: {e}", ephemeral=True)


@bot.tree.command(name="sys_unlock", description="♻️ Quita de la lista negra y desbanea")
@app_commands.describe(id_usuario="ID del usuario")
@app_commands.guild_only()
@app_commands.checks.has_permissions(ban_members=True)
@requires_key()
async def unpermaban(interaction: discord.Interaction, id_usuario: str):
    await interaction.response.defer(ephemeral=True)
    if not id_usuario.isdigit():
        await interaction.followup.send("Debes dar un ID numérico.", ephemeral=True)
        return
    data["blacklist"].get(str(interaction.guild.id), {}).pop(id_usuario, None)
    save_data()
    try:
        await interaction.guild.unban(discord.Object(id=int(id_usuario)))
        await interaction.followup.send(f"✅ `{id_usuario}` desbaneado y quitado de la lista negra.",
                                        ephemeral=True)
    except discord.NotFound:
        await interaction.followup.send("Ese usuario no estaba baneado (ya se quitó de la lista negra).",
                                        ephemeral=True)


@bot.tree.command(name="sys_records", description="📋 Muestra la lista negra del servidor")
@app_commands.guild_only()
@app_commands.checks.has_permissions(ban_members=True)
@requires_key()
async def listanegra(interaction: discord.Interaction):
    entries = data["blacklist"].get(str(interaction.guild.id), {})
    if not entries:
        await interaction.response.send_message("La lista negra está vacía.", ephemeral=True)
        return
    text = "\n".join(f"`{uid}` — {r}" for uid, r in list(entries.items())[:40])
    await interaction.response.send_message(embed=discord.Embed(
        title=f"📋 Lista negra ({len(entries)})", description=text[:4000], color=0xC0392B), ephemeral=True)


@bot.tree.command(name="sys_raid", description="🚨 Bloquea manualmente las entradas al servidor (emergencias)")
@app_commands.describe(estado="Activar, desactivar o ver el estado", minutos="Duración del bloqueo (por defecto 30)")
@app_commands.choices(estado=[
    app_commands.Choice(name="Activar bloqueo", value="on"),
    app_commands.Choice(name="Desactivar bloqueo", value="off"),
    app_commands.Choice(name="Ver estado", value="status"),
])
@app_commands.guild_only()
@app_commands.checks.has_permissions(manage_guild=True)
@requires_key()
async def sys_raid(interaction: discord.Interaction, estado: app_commands.Choice[str],
                   minutos: app_commands.Range[int, 1, 1440] = 30):
    gid = interaction.guild.id
    now = time.time()
    if estado.value == "on":
        manual_lock_until[gid] = now + minutos * 60
        await interaction.response.send_message(
            f"🚨 Bloqueo activado **{minutos} min**: toda cuenta nueva será sancionada "
            f"(`{gcfg(gid, 'antiraid')['action']}`). Se cancela con `/sys_raid desactivar`.", ephemeral=True)
    elif estado.value == "off":
        manual_lock_until.pop(gid, None)
        raid_until.pop(gid, None)
        await interaction.response.send_message("✅ Bloqueo y modo raid desactivados.", ephemeral=True)
    else:
        left_m = manual_lock_until.get(gid, 0) - now
        left_a = raid_until.get(gid, 0) - now
        lines = [f"🔒 Bloqueo manual: **{'activo, ' + fmt_wait(left_m) if left_m > 0 else 'inactivo'}**",
                 f"🚨 Modo raid automático: **{'activo, ' + fmt_wait(left_a) if left_a > 0 else 'inactivo'}**",
                 f"🛡️ Antiraid: **{'activado' if gcfg(gid, 'antiraid')['enabled'] else 'desactivado'}**"]
        await interaction.response.send_message("\n".join(lines), ephemeral=True)


# =====================================================================
#  SORTEOS (giveaway)
# =====================================================================
def parse_duration(text: str) -> Optional[int]:
    m = re.fullmatch(r"\s*(\d+)\s*([smhd])\s*", text.lower())
    if not m:
        return None
    return int(m.group(1)) * {"s": 1, "m": 60, "h": 3600, "d": 86400}[m.group(2)]


def giveaway_embed(gw: dict, ended: bool = False, winners: Optional[list] = None) -> discord.Embed:
    description = gw.get("description") or "¡Participa y tendrás una oportunidad de ganar!"
    e = discord.Embed(
        title="🏁 SORTEO FINALIZADO" if ended else "🎉 ¡SORTEO ACTIVO!",
        description=f"**🎁 Premio:** {gw['prize']}\n\n{description}",
        color=0x95A5A6 if ended else 0xF1C40F)
    if gw.get("image") and re.match(r"^https?://\S+$", gw["image"], re.I):
        e.set_image(url=gw["image"])
    if ended:
        winner_text = ", ".join(f"<@{w}>" for w in (winners or [])) if winners else "Nadie participó"
        e.add_field(name="🏆 Ganadores", value=winner_text[:1024], inline=False)
    else:
        e.add_field(name="🏆 Ganadores", value=str(gw["winners"]), inline=True)
        e.add_field(name="👥 Participantes", value=str(len(gw["entries"])), inline=True)
        role_id = gw.get("required_role")
        e.add_field(name="🔐 Requisito", value=f"<@&{role_id}>" if role_id else "Abierto para todos", inline=True)
    e.add_field(name="⏰ Terminó" if ended else "⏰ Finaliza", value=f"<t:{int(gw['end'])}:R>", inline=True)
    e.add_field(name="🎙️ Organiza", value=f"<@{gw['host']}>", inline=True)
    e.set_footer(text="Pulsa el botón para participar • Sorteo transparente")
    return e


class GiveawayView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label="Participar", emoji="🎉", style=discord.ButtonStyle.primary, custom_id="gw:join")
    async def join(self, interaction: discord.Interaction, button: discord.ui.Button):
        gw = data["giveaways"].get(str(interaction.message.id))
        if not gw or gw["ended"]:
            await interaction.response.send_message("Este sorteo ya terminó.", ephemeral=True)
            return
        if interaction.user.bot:
            await interaction.response.send_message("🤖 Las cuentas de bot no pueden participar.", ephemeral=True)
            return
        uid = interaction.user.id
        required_role = gw.get("required_role")
        if required_role:
            member = interaction.guild.get_member(uid) if interaction.guild else None
            if not member or not any(role.id == required_role for role in member.roles):
                await interaction.response.send_message(
                    f"🔒 Necesitas el rol <@&{required_role}> para participar.", ephemeral=True)
                return
        if uid in gw["entries"]:
            gw["entries"].remove(uid)
            msg = "👋 Has salido del sorteo."
        else:
            gw["entries"].append(uid)
            msg = "✅ ¡Participación registrada! ¡Mucha suerte!"
        save_data()
        await interaction.response.send_message(f"{msg} ({len(gw['entries'])} participantes)", ephemeral=True)


async def finish_giveaway(msg_id: str, reroll: bool = False) -> bool:
    gw = data["giveaways"].get(msg_id)
    if not gw or (gw["ended"] and not reroll):
        return False
    guild = bot.get_guild(gw["guild"])
    channel = guild.get_channel(gw["channel"]) if guild else None
    entries = gw["entries"]
    winners = random.sample(entries, min(gw["winners"], len(entries))) if entries else []
    gw["ended"] = True
    gw["last_winners"] = winners
    save_data()
    if not channel:
        return True
    try:
        msg = await channel.fetch_message(int(msg_id))
        await msg.edit(embed=giveaway_embed(gw, True, winners), view=None)
    except discord.HTTPException:
        pass
    try:
        if winners:
            mentions = " ".join(f"<@{w}>" for w in winners)
            host = guild.get_member(gw["host"])
            ctx = variable_values(guild=guild, channel=channel, extra={
                "{prize}": gw["prize"], "{winners}": mentions,
                "{host}": host.display_name if host else "", "{host_mention}": f"<@{gw['host']}>"})
            if not await send_saved(channel, gw["guild"], gcfg(gw["guild"], "sorteos").get("winner_embed"), ctx,
                                    content=mentions, allowed_mentions=discord.AllowedMentions(users=True)):
                await channel.send(f"🎊 ¡Felicidades {mentions}! Ganaste **{gw['prize']}**")
        else:
            await channel.send(f"😢 Nadie participó en el sorteo de **{gw['prize']}**.")
    except discord.HTTPException:
        pass
    if winners and gcfg(gw["guild"], "sorteos")["dm_winner"]:
        for w in winners:
            m = guild.get_member(w)
            if m:
                try:
                    await m.send(f"🎉 ¡Ganaste **{gw['prize']}** en **{guild.name}**!")
                except discord.HTTPException:
                    pass
    return True


@tasks.loop(seconds=10)
async def giveaway_loop():
    now = time.time()
    for mid, gw in list(data["giveaways"].items()):
        if not guild_is_allowed(gw.get("guild")):
            continue
        if not gw["ended"] and gw["end"] <= now:
            try:
                await finish_giveaway(mid)
            except Exception as e:
                print("Error terminando sorteo:", e)


@giveaway_loop.before_loop
async def _before_giveaway():
    await bot.wait_until_ready()


URL_RE = re.compile(r"^https?://\S+$", re.I)


@bot.tree.command(name="event_start", description="🎉 Crea un sorteo")
@app_commands.describe(premio="Qué se sortea", duracion="Ej: 30s, 10m, 2h, 1d",
                       ganadores="Número de ganadores", canal="Canal donde publicarlo",
                       rol_requerido="Rol necesario para participar (opcional)",
                       descripcion="Reglas o detalles del sorteo (opcional)",
                       imagen="URL de una imagen del premio (opcional)")
@app_commands.guild_only()
@app_commands.checks.has_permissions(manage_guild=True)
@requires_key()
async def sorteo(interaction: discord.Interaction, premio: str, duracion: str,
                 ganadores: Optional[app_commands.Range[int, 1, 20]] = None,
                 canal: Optional[discord.TextChannel] = None,
                 rol_requerido: Optional[discord.Role] = None,
                 descripcion: Optional[str] = None,
                 imagen: Optional[str] = None):
    secs = parse_duration(duracion)
    if not secs or secs < 5 or secs > 30 * 86400:
        await interaction.response.send_message("❌ Duración inválida. Ejemplos: `30s`, `10m`, `2h`, `1d` "
                                                "(máx. 30 días).", ephemeral=True)
        return
    if len(premio.strip()) > 200:
        await interaction.response.send_message("❌ El nombre del premio no puede superar 200 caracteres.", ephemeral=True)
        return
    if imagen and not URL_RE.match(imagen.strip()):
        await interaction.response.send_message("❌ La imagen debe ser una URL que empiece por http:// o https://.", ephemeral=True)
        return
    cfg = gcfg(interaction.guild.id, "sorteos")
    if canal is None:
        canal = interaction.guild.get_channel(cfg["channel"]) if cfg["channel"] else interaction.channel
    if canal is None:
        await interaction.response.send_message("❌ No encontré el canal configurado para sorteos.", ephemeral=True)
        return
    gw = {"guild": interaction.guild.id, "channel": canal.id, "prize": premio.strip(),
          "description": (descripcion or "").strip()[:1000],
          "image": imagen.strip() if imagen else "",
          "required_role": rol_requerido.id if rol_requerido else None,
          "winners": ganadores or cfg["default_winners"] or 1, "end": time.time() + secs,
          "host": interaction.user.id, "entries": [], "ended": False}
    ping = f"<@&{cfg['ping_role']}>" if cfg["ping_role"] else None
    try:
        msg = await canal.send(content=ping, embed=giveaway_embed(gw), view=GiveawayView(),
                               allowed_mentions=discord.AllowedMentions(roles=True))
    except discord.HTTPException:
        await interaction.response.send_message("❌ No pude enviar el mensaje en ese canal.", ephemeral=True)
        return
    data["giveaways"][str(msg.id)] = gw
    save_data()
    await interaction.response.send_message(f"✅ Sorteo creado en {canal.mention}. ID: `{msg.id}`",
                                            ephemeral=True)


@bot.tree.command(name="event_end", description="🏁 Termina un sorteo ahora mismo")
@app_commands.describe(mensaje_id="ID del mensaje del sorteo")
@app_commands.guild_only()
@app_commands.checks.has_permissions(manage_guild=True)
@requires_key()
async def sorteo_terminar(interaction: discord.Interaction, mensaje_id: str):
    gw = data["giveaways"].get(mensaje_id.strip())
    if not gw or gw["guild"] != interaction.guild.id:
        await interaction.response.send_message("❌ No encontré ese sorteo.", ephemeral=True)
        return
    await interaction.response.defer(ephemeral=True)
    ok = await finish_giveaway(mensaje_id.strip())
    await interaction.followup.send("✅ Sorteo terminado." if ok else "Ese sorteo ya había terminado.",
                                    ephemeral=True)


@bot.tree.command(name="event_reroll", description="🔁 Elige nuevos ganadores de un sorteo terminado")
@app_commands.describe(mensaje_id="ID del mensaje del sorteo")
@app_commands.guild_only()
@app_commands.checks.has_permissions(manage_guild=True)
@requires_key()
async def sorteo_reroll(interaction: discord.Interaction, mensaje_id: str):
    gw = data["giveaways"].get(mensaje_id.strip())
    if not gw or gw["guild"] != interaction.guild.id or not gw["ended"]:
        await interaction.response.send_message("❌ Ese sorteo no existe o aún no terminó.", ephemeral=True)
        return
    await interaction.response.defer(ephemeral=True)
    await finish_giveaway(mensaje_id.strip(), reroll=True)
    await interaction.followup.send("🔁 Nuevos ganadores elegidos.", ephemeral=True)


# =====================================================================
#  INVITES
# =====================================================================
@bot.tree.command(name="invite_stats", description="📨 Mira cuántas personas ha invitado alguien")
@app_commands.guild_only()
@requires_key()
async def invites_cmd(interaction: discord.Interaction, usuario: Optional[discord.Member] = None):
    usuario = usuario or interaction.user
    st = data["invites"].get(str(interaction.guild.id), {}).get("stats", {}).get(
        str(usuario.id), {"joins": 0, "left": 0})
    e = discord.Embed(title=f"📨 Invitaciones de {usuario.display_name}", color=0x3498DB)
    e.add_field(name="✅ Entradas", value=str(st["joins"]))
    e.add_field(name="📤 Salieron", value=str(st["left"]))
    e.add_field(name="👥 Activos", value=str(st["joins"] - st["left"]))
    await interaction.response.send_message(embed=e)


@bot.tree.command(name="invite_rank", description="🏆 Ranking de invitaciones")
@app_commands.guild_only()
@requires_key()
async def top_invites(interaction: discord.Interaction):
    stats = data["invites"].get(str(interaction.guild.id), {}).get("stats", {})
    if not stats:
        await interaction.response.send_message("Aún no hay datos de invitaciones.", ephemeral=True)
        return
    ranking = sorted(stats.items(), key=lambda kv: kv[1]["joins"] - kv[1]["left"], reverse=True)[:10]
    medals = ["🥇", "🥈", "🥉"] + ["🔹"] * 7
    text = "\n".join(f"{medals[i]} <@{uid}> — **{s['joins'] - s['left']}** activos ({s['joins']} total)"
                     for i, (uid, s) in enumerate(ranking))
    await interaction.response.send_message(embed=discord.Embed(
        title="🏆 Top invitaciones", description=text, color=0x3498DB))


# =====================================================================
#  DIVERSIÓN: economía, niveles, juegos
# =====================================================================
async def module_on(interaction: discord.Interaction) -> bool:
    if not gcfg(interaction.guild.id, "diversion")["enabled"]:
        await interaction.response.send_message("🎮 El módulo de diversión está desactivado.", ephemeral=True)
        return False
    return True


def cur(interaction: discord.Interaction) -> str:
    return gcfg(interaction.guild.id, "diversion")["currency"]


def fmt_wait(seconds: float) -> str:
    seconds = int(seconds)
    h, rem = divmod(seconds, 3600)
    m, s = divmod(rem, 60)
    return " ".join(p for p in (f"{h}h" if h else "", f"{m}m" if m else "", f"{s}s") if p)


@bot.tree.command(name="wallet", description="💰 Mira tu dinero")
@app_commands.guild_only()
@requires_key()
async def balance(interaction: discord.Interaction, usuario: Optional[discord.Member] = None):
    if not await module_on(interaction):
        return
    usuario = usuario or interaction.user
    u = eco(interaction.guild.id, usuario.id)
    await interaction.response.send_message(
        embed=discord.Embed(title=f"💰 {usuario.display_name}", color=0xF1C40F,
                            description=f"**{u['coins']:,}** {cur(interaction)}"))


@bot.tree.command(name="claim", description="🎁 Reclama tu recompensa diaria")
@app_commands.guild_only()
@requires_key()
async def daily(interaction: discord.Interaction):
    if not await module_on(interaction):
        return
    u = eco(interaction.guild.id, interaction.user.id)
    wait = 86400 - (time.time() - u["last_daily"])
    if wait > 0:
        await interaction.response.send_message(f"⏳ Vuelve en **{fmt_wait(wait)}**.", ephemeral=True)
        return
    amount = gcfg(interaction.guild.id, "diversion")["daily"]
    u["coins"] += amount
    u["last_daily"] = time.time()
    save_data()
    await interaction.response.send_message(f"🎁 Recibiste **{amount:,}** {cur(interaction)}.")


@bot.tree.command(name="shift", description="⛏️ Trabaja para ganar dinero (cada 1 hora)")
@app_commands.guild_only()
@requires_key()
async def trabajar(interaction: discord.Interaction):
    if not await module_on(interaction):
        return
    u = eco(interaction.guild.id, interaction.user.id)
    wait = 3600 - (time.time() - u["last_work"])
    if wait > 0:
        await interaction.response.send_message(f"⏳ Descansa **{fmt_wait(wait)}** más.", ephemeral=True)
        return
    dv = gcfg(interaction.guild.id, "diversion")
    lo, hi = sorted((dv["work_min"], dv["work_max"]))
    amount = random.randint(lo, hi)
    job = random.choice(["programador", "panadero", "minero", "streamer", "repartidor", "pescador"])
    u["coins"] += amount
    u["last_work"] = time.time()
    save_data()
    await interaction.response.send_message(f"⛏️ Trabajaste de **{job}** y ganaste **{amount:,}** {dv['currency']}.")


@bot.tree.command(name="wager", description="🎲 Apuesta tu dinero (50% de ganar el doble)")
@app_commands.guild_only()
@requires_key()
async def apostar(interaction: discord.Interaction, cantidad: app_commands.Range[int, 1, 1_000_000]):
    if not await module_on(interaction):
        return
    u = eco(interaction.guild.id, interaction.user.id)
    if cantidad > u["coins"]:
        await interaction.response.send_message("❌ No tienes suficiente dinero.", ephemeral=True)
        return
    if random.random() < 0.5:
        u["coins"] += cantidad
        msg = f"🎉 ¡Ganaste **{cantidad:,}** {cur(interaction)}!"
    else:
        u["coins"] -= cantidad
        msg = f"💸 Perdiste **{cantidad:,}** {cur(interaction)}."
    save_data()
    await interaction.response.send_message(msg)


@bot.tree.command(name="transfer", description="🤝 Dale dinero a otro usuario")
@app_commands.guild_only()
@requires_key()
async def dar(interaction: discord.Interaction, usuario: discord.Member,
              cantidad: app_commands.Range[int, 1, 1_000_000]):
    if not await module_on(interaction):
        return
    if usuario.bot or usuario.id == interaction.user.id:
        await interaction.response.send_message("❌ Destinatario inválido.", ephemeral=True)
        return
    a = eco(interaction.guild.id, interaction.user.id)
    if cantidad > a["coins"]:
        await interaction.response.send_message("❌ No tienes suficiente dinero.", ephemeral=True)
        return
    b = eco(interaction.guild.id, usuario.id)
    a["coins"] -= cantidad
    b["coins"] += cantidad
    save_data()
    await interaction.response.send_message(f"🤝 {interaction.user.mention} le dio **{cantidad:,}** "
                                            f"{cur(interaction)} a {usuario.mention}.")


@bot.tree.command(name="wealth", description="🏆 Los más ricos del servidor")
@app_commands.guild_only()
@requires_key()
async def top(interaction: discord.Interaction):
    if not await module_on(interaction):
        return
    users = data["economy"].get(str(interaction.guild.id), {})
    ranking = sorted(users.items(), key=lambda kv: kv[1]["coins"], reverse=True)[:10]
    if not ranking:
        await interaction.response.send_message("Aún no hay datos.", ephemeral=True)
        return
    medals = ["🥇", "🥈", "🥉"] + ["🔹"] * 7
    text = "\n".join(f"{medals[i]} <@{uid}> — **{u['coins']:,}** {cur(interaction)}"
                     for i, (uid, u) in enumerate(ranking))
    await interaction.response.send_message(embed=discord.Embed(title="🏆 Top dinero", description=text,
                                                                color=0xF1C40F))


@bot.tree.command(name="level", description="📈 Mira tu nivel")
@app_commands.guild_only()
@requires_key()
async def rank(interaction: discord.Interaction, usuario: Optional[discord.Member] = None):
    if not await module_on(interaction):
        return
    usuario = usuario or interaction.user
    u = eco(interaction.guild.id, usuario.id)
    need = 5 * u["level"] ** 2 + 50 * u["level"] + 100
    filled = int(10 * u["xp"] / need)
    bar = "🟩" * filled + "⬛" * (10 - filled)
    e = discord.Embed(title=f"📈 {usuario.display_name}", color=0x2ECC71)
    e.add_field(name="Nivel", value=str(u["level"]))
    e.add_field(name="XP", value=f"{u['xp']}/{need}")
    e.add_field(name="Progreso", value=bar, inline=False)
    e.set_thumbnail(url=usuario.display_avatar.url)
    await interaction.response.send_message(embed=e)


@bot.tree.command(name="oracle", description="🎱 Pregúntale a la bola mágica")
@requires_key()
async def eight_ball(interaction: discord.Interaction, pregunta: str):
    answers = ["Sí, definitivamente.", "Sin duda.", "Todo apunta a que sí.", "Quizás.", "No estoy seguro.",
               "Pregunta de nuevo más tarde.", "No cuentes con ello.", "Mi respuesta es no.", "Muy dudoso."]
    await interaction.response.send_message(f"🎱 **{pregunta}**\n{random.choice(answers)}")


@bot.tree.command(name="coinflip", description="🪙 Lanza una moneda")
@requires_key()
async def moneda(interaction: discord.Interaction):
    await interaction.response.send_message(f"🪙 Salió **{random.choice(['cara', 'cruz'])}**.")


@bot.tree.command(name="hug", description="🤗 Abraza a alguien")
@app_commands.guild_only()
@requires_key()
async def abrazar(interaction: discord.Interaction, usuario: discord.Member):
    await interaction.response.send_message(f"🤗 {interaction.user.mention} abrazó a {usuario.mention}.")


@bot.tree.command(name="pfp", description="🖼️ Muestra el avatar de alguien")
@requires_key()
async def avatar(interaction: discord.Interaction, usuario: Optional[discord.User] = None):
    usuario = usuario or interaction.user
    e = discord.Embed(title=f"🖼️ {usuario.display_name}", color=0x5865F2)
    e.set_image(url=usuario.display_avatar.url)
    await interaction.response.send_message(embed=e)


# =====================================================================
#  TICKETS
# =====================================================================
async def build_transcript(channel: discord.TextChannel) -> io.BytesIO:
    lines = []
    async for m in channel.history(limit=None, oldest_first=True):
        ts = m.created_at.strftime("%Y-%m-%d %H:%M:%S")
        att = " ".join(a.url for a in m.attachments)
        lines.append(f"[{ts}] {m.author} ({m.author.id}): {m.clean_content} {att}".rstrip())
    return io.BytesIO("\n".join(lines).encode("utf-8"))


class TicketOpenView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label="Abrir ticket", emoji="🎫", style=discord.ButtonStyle.success,
                       custom_id="ticket:open")
    async def open_ticket(self, interaction: discord.Interaction, button: discord.ui.Button):
        guild, user = interaction.guild, interaction.user
        cfg = gcfg(guild.id, "tickets")

        for ch in guild.text_channels:
            if ch.topic == f"ticket:{user.id}":
                await interaction.response.send_message(f"Ya tienes un ticket abierto: {ch.mention}",
                                                        ephemeral=True)
                return

        await interaction.response.defer(ephemeral=True)
        overwrites = {
            guild.default_role: discord.PermissionOverwrite(view_channel=False),
            user: discord.PermissionOverwrite(view_channel=True, send_messages=True, attach_files=True,
                                              read_message_history=True),
            guild.me: discord.PermissionOverwrite(view_channel=True, send_messages=True, manage_channels=True,
                                                  read_message_history=True),
        }
        staff = guild.get_role(cfg["staff_role"]) if cfg["staff_role"] else None
        if staff:
            overwrites[staff] = discord.PermissionOverwrite(view_channel=True, send_messages=True,
                                                            attach_files=True, read_message_history=True)
        category = guild.get_channel(cfg["category"]) if cfg["category"] else None
        if not isinstance(category, discord.CategoryChannel):
            category = None

        cfg["counter"] += 1
        save_data()
        try:
            channel = await guild.create_text_channel(
                f"ticket-{cfg['counter']:04d}", category=category, overwrites=overwrites,
                topic=f"ticket:{user.id}", reason=f"Ticket de {user}")
        except discord.HTTPException as e:
            await interaction.followup.send(f"❌ No pude crear el ticket: {e}", ephemeral=True)
            return

        ctx = variable_values(user=user, guild=guild, channel=channel,
                              extra={"{ticket}": f"{cfg['counter']:04d}"})
        e = render_saved_embed(guild.id, cfg.get("welcome_embed"), ctx)
        if e is None:
            e = discord.Embed(title="🎫 Ticket abierto", description=cfg["welcome"], color=0x2ECC71)
            e.set_footer(text=f"Ticket #{cfg['counter']:04d}")
        mention = f"{user.mention} {staff.mention}" if staff else user.mention
        await channel.send(content=mention, embed=e, view=TicketCloseView(),
                           allowed_mentions=discord.AllowedMentions(users=True, roles=True))
        await interaction.followup.send(f"✅ Ticket creado: {channel.mention}", ephemeral=True)


class TicketCloseView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label="Cerrar ticket", emoji="🔒", style=discord.ButtonStyle.danger,
                       custom_id="ticket:close")
    async def close_ticket(self, interaction: discord.Interaction, button: discord.ui.Button):
        channel = interaction.channel
        cfg = gcfg(interaction.guild.id, "tickets")
        topic = channel.topic or ""
        owner_id = int(topic.split(":")[1]) if topic.startswith("ticket:") else None
        user = interaction.user
        is_staff = user.guild_permissions.manage_channels or (
            cfg["staff_role"] and any(r.id == cfg["staff_role"] for r in user.roles))
        if user.id != owner_id and not is_staff:
            await interaction.response.send_message("❌ Solo el dueño del ticket o el staff puede cerrarlo.",
                                                    ephemeral=True)
            return

        await interaction.response.send_message("🔒 Cerrando el ticket en 5 segundos…")
        if cfg["transcripts"] and cfg["log_channel"]:
            log = interaction.guild.get_channel(cfg["log_channel"])
            if log:
                try:
                    buf = await build_transcript(channel)
                    e = discord.Embed(title="📄 Ticket cerrado", color=0x95A5A6,
                                      description=f"**Canal:** {channel.name}\n"
                                                  f"**Dueño:** <@{owner_id}>\n**Cerrado por:** {user.mention}")
                    await log.send(embed=e, file=discord.File(buf, filename=f"{channel.name}.txt"))
                except discord.HTTPException:
                    pass
        await asyncio.sleep(5)
        try:
            await channel.delete(reason=f"Ticket cerrado por {user}")
        except discord.HTTPException:
            pass


@bot.tree.command(name="sys_support", description="🎫 Envía el panel para abrir tickets")
@app_commands.describe(canal="Canal donde enviarlo (por defecto, este)")
@app_commands.guild_only()
@app_commands.checks.has_permissions(manage_guild=True)
@requires_key()
async def ticket_panel(interaction: discord.Interaction, canal: Optional[discord.TextChannel] = None):
    canal = canal or interaction.channel
    e = render_saved_embed(interaction.guild.id, gcfg(interaction.guild.id, "tickets").get("panel_embed"),
                           variable_values(user=interaction.user, guild=interaction.guild, channel=canal))
    if e is None:
        e = discord.Embed(title="🎫 Soporte", color=0x2ECC71,
                          description="¿Necesitas ayuda? Pulsa el botón de abajo para abrir un ticket privado "
                                      "con el staff.")
    try:
        await canal.send(embed=e, view=TicketOpenView())
    except discord.HTTPException:
        await interaction.response.send_message("❌ No pude enviar el panel a ese canal.", ephemeral=True)
        return
    await interaction.response.send_message(f"✅ Panel enviado a {canal.mention}.", ephemeral=True)


@bot.tree.command(name="ticket_add", description="➕ Añade a un usuario al ticket actual")
@app_commands.guild_only()
@app_commands.checks.has_permissions(manage_channels=True)
@requires_key()
async def ticket_add(interaction: discord.Interaction, usuario: discord.Member):
    ch = interaction.channel
    if not (ch.topic or "").startswith("ticket:"):
        await interaction.response.send_message("❌ Esto no es un ticket.", ephemeral=True)
        return
    await ch.set_permissions(usuario, view_channel=True, send_messages=True, read_message_history=True)
    await interaction.response.send_message(f"✅ {usuario.mention} añadido al ticket.")


# =====================================================================
#  MODERACIÓN Y UTILIDAD
# =====================================================================
def can_act(interaction: discord.Interaction, target: discord.Member) -> bool:
    if target.id == interaction.guild.owner_id or target.id == interaction.user.id:
        return False
    if interaction.user.id == interaction.guild.owner_id:
        return True
    return target.top_role < interaction.user.top_role


@bot.tree.command(name="sys_remove", description="👢 Expulsa a un miembro")
@app_commands.guild_only()
@app_commands.checks.has_permissions(kick_members=True)
@requires_key()
async def kick(interaction: discord.Interaction, usuario: discord.Member, razon: str = "Sin razón"):
    if not can_act(interaction, usuario):
        await interaction.response.send_message("❌ No puedes sancionar a ese usuario.", ephemeral=True)
        return
    try:
        await usuario.kick(reason=f"{razon} (por {interaction.user})")
        await interaction.response.send_message(f"👢 {usuario} fue expulsado. Motivo: {razon}")
    except discord.HTTPException as e:
        await interaction.response.send_message(f"❌ No pude expulsarlo: {e}", ephemeral=True)


@bot.tree.command(name="sys_timeout", description="🔇 Aplica un timeout a un miembro")
@app_commands.describe(minutos="Duración en minutos (máx. 40320 = 28 días)")
@app_commands.guild_only()
@app_commands.checks.has_permissions(moderate_members=True)
@requires_key()
async def silenciar(interaction: discord.Interaction, usuario: discord.Member,
                    minutos: app_commands.Range[int, 1, 40320], razon: str = "Sin razón"):
    if not can_act(interaction, usuario):
        await interaction.response.send_message("❌ No puedes sancionar a ese usuario.", ephemeral=True)
        return
    try:
        await usuario.timeout(timedelta(minutes=minutos), reason=f"{razon} (por {interaction.user})")
        await interaction.response.send_message(f"🔇 {usuario.mention} silenciado por {minutos} min.")
    except discord.HTTPException as e:
        await interaction.response.send_message(f"❌ No pude silenciarlo: {e}", ephemeral=True)


@bot.tree.command(name="sys_sweep", description="🧹 Borra mensajes del canal")
@app_commands.guild_only()
@app_commands.checks.has_permissions(manage_messages=True)
@requires_key()
async def limpiar(interaction: discord.Interaction, cantidad: app_commands.Range[int, 1, 100]):
    await interaction.response.defer(ephemeral=True)
    deleted = await interaction.channel.purge(limit=cantidad)
    await interaction.followup.send(f"🧹 Borré {len(deleted)} mensajes.", ephemeral=True)


@bot.tree.command(name="sys_user", description="👤 Información de un usuario")
@app_commands.guild_only()
@requires_key()
async def userinfo(interaction: discord.Interaction, usuario: Optional[discord.Member] = None):
    u = usuario or interaction.user
    e = discord.Embed(title=f"👤 {u}", color=u.color or 0x5865F2)
    e.add_field(name="ID", value=f"`{u.id}`")
    e.add_field(name="Bot", value="Sí" if u.bot else "No")
    e.add_field(name="Cuenta creada", value=discord.utils.format_dt(u.created_at, "F"), inline=False)
    if u.joined_at:
        e.add_field(name="Entró al servidor", value=discord.utils.format_dt(u.joined_at, "F"), inline=False)
    e.set_thumbnail(url=u.display_avatar.url)
    await interaction.response.send_message(embed=e)


@bot.tree.command(name="sys_server", description="🏠 Información del servidor")
@app_commands.guild_only()
@requires_key()
async def serverinfo(interaction: discord.Interaction):
    g = interaction.guild
    e = discord.Embed(title=f"🏠 {g.name}", color=0x5865F2)
    e.add_field(name="👑 Dueño", value=f"<@{g.owner_id}>")
    e.add_field(name="👥 Miembros", value=str(g.member_count))
    e.add_field(name="💬 Canales", value=str(len(g.channels)))
    e.add_field(name="🎭 Roles", value=str(len(g.roles)))
    e.add_field(name="📅 Creado", value=discord.utils.format_dt(g.created_at, "F"), inline=False)
    if g.icon:
        e.set_thumbnail(url=g.icon.url)
    await interaction.response.send_message(embed=e)


@bot.tree.command(name="sys_ping", description="🏓 Latencia del bot")
@requires_key()
async def ping(interaction: discord.Interaction):
    await interaction.response.send_message(f"🏓 Pong! **{round(bot.latency * 1000)} ms**")


# =====================================================================
#  CREADOR DE EMBEDS (/embed) con interfaz interactiva
# =====================================================================
NAMED_COLORS = {
    "rojo": 0xE74C3C, "azul": 0x3498DB, "verde": 0x2ECC71, "amarillo": 0xF1C40F, "morado": 0x9B59B6,
    "rosa": 0xE91E63, "naranja": 0xE67E22, "negro": 0x010101, "blanco": 0xFFFFFF, "celeste": 0x1ABC9C,
    "gris": 0x95A5A6, "blurple": 0x5865F2,
}


def parse_color(text: str) -> int:
    t = text.strip().lower()
    if t in NAMED_COLORS:
        return NAMED_COLORS[t]
    m = re.fullmatch(r"#?([0-9a-f]{6})", t)
    if m:
        return int(m.group(1), 16)
    raise ValueError("Color inválido. Usa HEX (#FF0000) o un nombre: " + ", ".join(NAMED_COLORS))


def parse_url(text: str) -> Optional[str]:
    t = text.strip()
    if not t:
        return None
    # Permite una variable completa como {server_icon} o {user_avatar};
    # se reemplaza por una URL real al enviar el embed.
    if re.fullmatch(r"\{[a-zA-Z_]+\}", t):
        return t
    if not URL_RE.match(t):
        raise ValueError("Usa una URL http(s) o una variable de imagen como {server_icon} o {user_avatar}.")
    return t


class EmbedState:
    def __init__(self, image: Optional[discord.Attachment] = None, icon: Optional[discord.Attachment] = None):
        self.title: Optional[str] = "Título del embed"
        self.description: Optional[str] = "Descripción del embed. Usa los botones de abajo para editarlo."
        self.color: int = 0x5865F2
        self.image_url: Optional[str] = None
        self.image_att = image
        self.thumb_url: Optional[str] = None
        self.thumb_att = icon
        self.author_name: Optional[str] = None
        self.author_icon: Optional[str] = None
        self.footer_text: Optional[str] = None
        self.footer_icon: Optional[str] = None
        self.timestamp = False
        self.fields: list = []  # (nombre, valor, inline)
        self.channel_id: Optional[int] = None

    def to_dict(self) -> dict:
        """Versión guardable (las imágenes adjuntas no se guardan: caducan)."""
        return {"title": self.title, "description": self.description, "color": self.color,
                "image_url": self.image_url, "thumb_url": self.thumb_url,
                "author_name": self.author_name, "author_icon": self.author_icon,
                "footer_text": self.footer_text, "footer_icon": self.footer_icon,
                "timestamp": self.timestamp, "fields": [list(f) for f in self.fields]}

    @classmethod
    def from_dict(cls, d: dict) -> "EmbedState":
        st = cls()
        st.title, st.description = d.get("title"), d.get("description")
        st.color = d.get("color", 0x5865F2)
        st.image_url, st.thumb_url = d.get("image_url"), d.get("thumb_url")
        st.author_name, st.author_icon = d.get("author_name"), d.get("author_icon")
        st.footer_text, st.footer_icon = d.get("footer_text"), d.get("footer_icon")
        st.timestamp = bool(d.get("timestamp"))
        st.fields = [tuple(f) for f in d.get("fields", [])]
        return st

    def is_empty(self) -> bool:
        return not (self.title or self.description or self.fields or self.image_att or self.image_url
                    or self.thumb_att or self.thumb_url or self.author_name or self.footer_text)


def build_custom_embed(st: EmbedState, for_send: bool = False):
    e = discord.Embed(color=st.color)
    uploads = []  # (adjunto, nombre_de_archivo) que se re-suben al enviar
    if st.title:
        e.title = st.title
    if st.description:
        e.description = st.description

    if st.image_att:
        if for_send:
            name = "imagen" + os.path.splitext(st.image_att.filename)[1]
            uploads.append((st.image_att, name))
            e.set_image(url=f"attachment://{name}")
        else:
            e.set_image(url=st.image_att.url)
    elif st.image_url:
        e.set_image(url=st.image_url)

    if st.thumb_att:
        if for_send:
            name = "icono" + os.path.splitext(st.thumb_att.filename)[1]
            uploads.append((st.thumb_att, name))
            e.set_thumbnail(url=f"attachment://{name}")
        else:
            e.set_thumbnail(url=st.thumb_att.url)
    elif st.thumb_url:
        e.set_thumbnail(url=st.thumb_url)

    if st.author_name:
        e.set_author(name=st.author_name, icon_url=st.author_icon)
    for n, v, inline in st.fields:
        e.add_field(name=n, value=v, inline=inline)
    if st.footer_text:
        e.set_footer(text=st.footer_text, icon_url=st.footer_icon)
    if st.timestamp:
        e.timestamp = discord.utils.utcnow()
    return e, uploads


class TitleDescModal(discord.ui.Modal, title="📝 Título y descripción"):
    def __init__(self, view: "EmbedBuilderView"):
        super().__init__()
        self.pview = view
        self.title_in = discord.ui.TextInput(label="Nombre / título del embed (admite emojis)", default=view.st.title or "", required=False,
                                             max_length=256, placeholder="✨ ¡Bienvenido a {server}, {user}!")
        self.desc_in = discord.ui.TextInput(label="Texto del embed (admite emojis)", style=discord.TextStyle.paragraph,
                                            default=view.st.description or "", required=False, max_length=4000,
                                            placeholder="Admite emojis y variables: {user}, {username}, {server}, {count}, {id}, {channel}, {date}")
        self.add_item(self.title_in)
        self.add_item(self.desc_in)

    async def on_submit(self, interaction: discord.Interaction):
        self.pview.st.title = self.title_in.value.strip() or None
        self.pview.st.description = self.desc_in.value.strip() or None
        await self.pview.refresh(interaction)


class ColorModal(discord.ui.Modal, title="🎨 Color del embed"):
    def __init__(self, view: "EmbedBuilderView"):
        super().__init__()
        self.pview = view
        self.color_in = discord.ui.TextInput(label="Color (HEX o nombre)", default=f"#{view.st.color:06X}",
                                             placeholder="#FF0000, rojo, azul, verde, morado…", max_length=20)
        self.add_item(self.color_in)

    async def on_submit(self, interaction: discord.Interaction):
        try:
            self.pview.st.color = parse_color(self.color_in.value)
        except ValueError as e:
            await interaction.response.send_message(f"❌ {e}", ephemeral=True)
            return
        await self.pview.refresh(interaction)


class ImageModal(discord.ui.Modal, title="🖼️ Imágenes"):
    def __init__(self, view: "EmbedBuilderView"):
        super().__init__()
        self.pview = view
        st = view.st
        self.img_in = discord.ui.TextInput(
            label="Imagen grande (URL)", required=False, max_length=500,
            default=st.image_url or ("adjunto" if st.image_att else ""),
            placeholder="https://… (vacío = quitar)")
        self.thumb_in = discord.ui.TextInput(
            label="Icono / miniatura (URL)", required=False, max_length=500,
            default=st.thumb_url or ("adjunto" if st.thumb_att else ""),
            placeholder="https://… (vacío = quitar)")
        self.add_item(self.img_in)
        self.add_item(self.thumb_in)

    async def on_submit(self, interaction: discord.Interaction):
        st = self.pview.st
        try:
            img = self.img_in.value.strip()
            thumb = self.thumb_in.value.strip()
            if img.lower() != "adjunto":
                st.image_url, st.image_att = parse_url(img), None
            if thumb.lower() != "adjunto":
                st.thumb_url, st.thumb_att = parse_url(thumb), None
        except ValueError as e:
            await interaction.response.send_message(f"❌ {e}", ephemeral=True)
            return
        await self.pview.refresh(interaction)


class AuthorModal(discord.ui.Modal, title="🔰 Autor"):
    def __init__(self, view: "EmbedBuilderView"):
        super().__init__()
        self.pview = view
        self.name_in = discord.ui.TextInput(label="Nombre del autor (admite emojis)", default=view.st.author_name or "",
                                            required=False, max_length=256, placeholder="🌟 Luminos Nova")
        self.icon_in = discord.ui.TextInput(label="Icono del autor (URL)", default=view.st.author_icon or "",
                                            required=False, max_length=500, placeholder="https://…")
        self.add_item(self.name_in)
        self.add_item(self.icon_in)

    async def on_submit(self, interaction: discord.Interaction):
        try:
            icon = parse_url(self.icon_in.value)
        except ValueError as e:
            await interaction.response.send_message(f"❌ {e}", ephemeral=True)
            return
        self.pview.st.author_name = self.name_in.value.strip() or None
        self.pview.st.author_icon = icon
        await self.pview.refresh(interaction)


class FooterModal(discord.ui.Modal, title="📎 Pie del embed"):
    def __init__(self, view: "EmbedBuilderView"):
        super().__init__()
        self.pview = view
        self.text_in = discord.ui.TextInput(label="Texto del pie (admite emojis)", default=view.st.footer_text or "",
                                            required=False, max_length=2048, placeholder="💜 Gracias por formar parte de la comunidad")
        self.icon_in = discord.ui.TextInput(label="Icono del pie (URL)", default=view.st.footer_icon or "",
                                            required=False, max_length=500, placeholder="https://…")
        self.add_item(self.text_in)
        self.add_item(self.icon_in)

    async def on_submit(self, interaction: discord.Interaction):
        try:
            icon = parse_url(self.icon_in.value)
        except ValueError as e:
            await interaction.response.send_message(f"❌ {e}", ephemeral=True)
            return
        self.pview.st.footer_text = self.text_in.value.strip() or None
        self.pview.st.footer_icon = icon
        await self.pview.refresh(interaction)


class FieldModal(discord.ui.Modal, title="➕ Añadir campo"):
    def __init__(self, view: "EmbedBuilderView"):
        super().__init__()
        self.pview = view
        self.name_in = discord.ui.TextInput(label="Nombre del campo (admite emojis y variables)", max_length=256, placeholder="🏷️ Información de {server}")
        self.value_in = discord.ui.TextInput(label="Valor (admite emojis y variables)", style=discord.TextStyle.paragraph, max_length=1024, placeholder="👋 Hola {user}; somos {server}.")
        self.inline_in = discord.ui.TextInput(label="¿En línea? (si / no)", default="no", max_length=3)
        self.add_item(self.name_in)
        self.add_item(self.value_in)
        self.add_item(self.inline_in)

    async def on_submit(self, interaction: discord.Interaction):
        inline = self.inline_in.value.strip().lower() in ("si", "sí", "s", "yes", "y", "true", "1")
        self.pview.st.fields.append((self.name_in.value.strip(), self.value_in.value.strip(), inline))
        await self.pview.refresh(interaction)


class EmojiPickerView(discord.ui.View):
    """Selector sencillo de emojis comunes para insertarlos en los textos del embed."""
    EMOJIS = ["👋", "🎉", "✨", "💜", "❤️", "🛡️", "📢", "📨", "🎮", "🏆", "🎁", "🔥", "✅", "⚠️", "❌", "⭐", "🌙", "🤖", "💎", "🚀"]

    def __init__(self, builder: "EmbedBuilderView"):
        super().__init__(timeout=180)
        self.builder = builder
        self.target = "description"
        self.emoji = "✨"
        targets = [
            discord.SelectOption(label="Título", value="title", emoji="📝"),
            discord.SelectOption(label="Descripción", value="description", emoji="💬"),
            discord.SelectOption(label="Autor", value="author", emoji="🔰"),
            discord.SelectOption(label="Pie", value="footer", emoji="📎"),
            discord.SelectOption(label="Nombre del campo", value="field_name", emoji="🏷️"),
            discord.SelectOption(label="Valor del campo", value="field_value", emoji="📄"),
        ]
        target_select = discord.ui.Select(placeholder="¿En qué texto quieres poner el emoji?", options=targets, row=0)
        target_select.callback = self.choose_target
        self.add_item(target_select)
        emoji_select = discord.ui.Select(placeholder="😀 Elige un emoji", options=[discord.SelectOption(label=e, value=e, emoji=e) for e in self.EMOJIS], row=1)
        emoji_select.callback = self.choose_emoji
        self.add_item(emoji_select)
        apply_button = discord.ui.Button(label="Insertar emoji", emoji="➕", style=discord.ButtonStyle.success, row=2)
        apply_button.callback = self.apply_emoji
        self.add_item(apply_button)
        back_button = discord.ui.Button(label="Volver", emoji="↩️", style=discord.ButtonStyle.secondary, row=2)
        back_button.callback = self.go_back
        self.add_item(back_button)

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id != self.builder.owner_id:
            await interaction.response.send_message("Este creador no es tuyo.", ephemeral=True)
            return False
        return True

    async def choose_target(self, interaction: discord.Interaction):
        self.target = interaction.data["values"][0]
        await interaction.response.edit_message(content=f"😀 Emoji seleccionado: **{self.emoji}** · Texto: **{self.target}**", view=self)

    async def choose_emoji(self, interaction: discord.Interaction):
        self.emoji = interaction.data["values"][0]
        await interaction.response.edit_message(content=f"😀 Emoji seleccionado: **{self.emoji}** · Texto: **{self.target}**", view=self)

    async def apply_emoji(self, interaction: discord.Interaction):
        st = self.builder.st
        if self.target == "title":
            st.title = f"{self.emoji} {st.title or ''}".strip()
        elif self.target == "description":
            st.description = f"{self.emoji} {st.description or ''}".strip()
        elif self.target == "author":
            st.author_name = f"{self.emoji} {st.author_name or ''}".strip()
        elif self.target == "footer":
            st.footer_text = f"{self.emoji} {st.footer_text or ''}".strip()
        elif self.target == "field_name" and st.fields:
            n, v, inline = st.fields[-1]
            st.fields[-1] = (f"{self.emoji} {n}", v, inline)
        elif self.target == "field_value" and st.fields:
            n, v, inline = st.fields[-1]
            st.fields[-1] = (n, f"{self.emoji} {v}", inline)
        elif self.target in ("field_name", "field_value"):
            await interaction.response.send_message("Primero añade un campo con el botón ➕ Añadir campo.", ephemeral=True)
            return
        await interaction.response.edit_message(content=self.builder.dest_text(), embed=self.builder.preview(), view=self.builder)
        self.stop()

    async def go_back(self, interaction: discord.Interaction):
        await interaction.response.edit_message(content=self.builder.dest_text(), embed=self.builder.preview(), view=self.builder)
        self.stop()


class SaveNameModal(discord.ui.Modal, title="💾 Guardar embed"):
    def __init__(self, view: "EmbedBuilderView"):
        super().__init__()
        self.pview = view
        self.name_in = discord.ui.TextInput(label="Nombre (letras, números, - y _)", max_length=32,
                                            placeholder="bienvenida-principal")
        self.add_item(self.name_in)

    async def on_submit(self, interaction: discord.Interaction):
        name = clean_embed_name(self.name_in.value)
        if not name:
            await interaction.response.send_message(
                "❌ Nombre inválido. Usa solo letras minúsculas, números, `-` y `_` (máx. 32).", ephemeral=True)
            return
        await self.pview.save(interaction, name)


class EmbedBuilderView(discord.ui.View):
    def __init__(self, owner_id: int, state: EmbedState, default_channel: int, save_name: Optional[str] = None):
        super().__init__(timeout=900)
        self.owner_id, self.st, self.default_channel = owner_id, state, default_channel
        self.save_name = save_name
        self.message = None

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id != self.owner_id:
            await interaction.response.send_message("Este creador no es tuyo.", ephemeral=True)
            return False
        return True

    def dest_text(self) -> str:
        text = f"📢 Se enviará en <#{self.st.channel_id or self.default_channel}>"
        if self.save_name:
            text += f"\n💾 Embed guardado: `{self.save_name}` — pulsa **Guardar** para actualizarlo"
        return text

    async def save(self, interaction: discord.Interaction, name: str):
        st = self.st
        if st.is_empty():
            await interaction.response.send_message("❌ El embed está vacío.", ephemeral=True)
            return
        store = embed_store(interaction.guild.id)
        if name not in store and len(store) >= MAX_SAVED_EMBEDS:
            await interaction.response.send_message(
                f"❌ Máximo {MAX_SAVED_EMBEDS} embeds guardados. Borra uno con `/embed_delete`.", ephemeral=True)
            return
        store[name] = st.to_dict()
        save_data()
        self.save_name = name
        note = ""
        if st.image_att or st.thumb_att:
            note = "\n⚠️ Las imágenes **adjuntas** no se guardan; usa una URL en el botón 🖼️ Imágenes."
        await self.edit_source_message(
            interaction,
            content=f"{self.dest_text()}\n✅ Guardado como `{name}`. Úsalo en `/panel` (variables 🖼️) "
                    f"o con `/embed_send`.{note}",
            embed=self.preview(), view=self)

    def preview(self) -> discord.Embed:
        if self.st.is_empty():
            return discord.Embed(description="*(embed vacío — añade título, descripción o imagen)*",
                                 color=0x2B2D31)
        return build_custom_embed(self.st)[0]

    async def edit_source_message(self, interaction: discord.Interaction, **kwargs):
        # Buttons/selects can edit their interaction response. Modal submits must edit the
        # original message stored when /embed was opened.
        if interaction.message is not None:
            await interaction.response.edit_message(**kwargs)
            return
        await interaction.response.defer(ephemeral=True, thinking=True)
        if self.message is None:
            await interaction.followup.send("⚠️ No se encontró el mensaje original del creador de embeds.", ephemeral=True)
            return
        try:
            await self.message.edit(**kwargs)
            await interaction.followup.send("✅ Cambios aplicados al creador de embeds.", ephemeral=True)
        except discord.HTTPException as exc:
            await interaction.followup.send(f"❌ No pude actualizar el mensaje: {exc}", ephemeral=True)

    async def refresh(self, interaction: discord.Interaction):
        try:
            await self.edit_source_message(interaction, content=self.dest_text(), embed=self.preview(), view=self)
        except discord.HTTPException as e:
            msg = f"❌ Discord rechazó el embed: {e}"
            if interaction.response.is_done():
                await interaction.followup.send(msg, ephemeral=True)
            else:
                await interaction.response.send_message(msg, ephemeral=True)

    # ----- Fila 0: edición -----
    @discord.ui.button(label="Título y descripción", emoji="📝", style=discord.ButtonStyle.primary, row=0)
    async def btn_text(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_modal(TitleDescModal(self))

    @discord.ui.button(label="Color", emoji="🎨", style=discord.ButtonStyle.primary, row=0)
    async def btn_color(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_modal(ColorModal(self))

    @discord.ui.button(label="Imágenes", emoji="🖼️", style=discord.ButtonStyle.primary, row=0)
    async def btn_images(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_modal(ImageModal(self))

    @discord.ui.button(label="Autor", emoji="🔰", style=discord.ButtonStyle.secondary, row=0)
    async def btn_author(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_modal(AuthorModal(self))

    @discord.ui.button(label="Pie", emoji="📎", style=discord.ButtonStyle.secondary, row=0)
    async def btn_footer(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_modal(FooterModal(self))

    # ----- Fila 1: campos y extras -----
    @discord.ui.button(label="Emojis", emoji="😀", style=discord.ButtonStyle.primary, row=1)
    async def btn_emojis(self, interaction: discord.Interaction, button: discord.ui.Button):
        picker = EmojiPickerView(self)
        await interaction.response.edit_message(content="😀 **Selector de emojis** · Elige dónde insertarlo y selecciona uno.", embed=None, view=picker)

    @discord.ui.button(label="Añadir campo", emoji="➕", style=discord.ButtonStyle.secondary, row=1)
    async def btn_add_field(self, interaction: discord.Interaction, button: discord.ui.Button):
        if len(self.st.fields) >= 10:
            await interaction.response.send_message("❌ Máximo 10 campos.", ephemeral=True)
            return
        await interaction.response.send_modal(FieldModal(self))

    @discord.ui.button(label="Quitar último campo", emoji="➖", style=discord.ButtonStyle.secondary, row=1)
    async def btn_del_field(self, interaction: discord.Interaction, button: discord.ui.Button):
        if self.st.fields:
            self.st.fields.pop()
        await self.refresh(interaction)

    @discord.ui.button(label="Fecha: OFF", emoji="🕒", style=discord.ButtonStyle.secondary, row=1)
    async def btn_timestamp(self, interaction: discord.Interaction, button: discord.ui.Button):
        self.st.timestamp = not self.st.timestamp
        button.label = "Fecha: ON" if self.st.timestamp else "Fecha: OFF"
        button.style = discord.ButtonStyle.success if self.st.timestamp else discord.ButtonStyle.secondary
        await self.refresh(interaction)

    @discord.ui.button(label="Reiniciar", emoji="♻️", style=discord.ButtonStyle.secondary, row=1)
    async def btn_reset(self, interaction: discord.Interaction, button: discord.ui.Button):
        channel_id = self.st.channel_id
        self.st = EmbedState()
        self.st.channel_id = channel_id
        await self.refresh(interaction)

    # ----- Fila 2: canal -----
    @discord.ui.select(cls=discord.ui.ChannelSelect, channel_types=[discord.ChannelType.text, discord.ChannelType.news],
                       placeholder="📢 Canal donde enviar (por defecto: este)", row=2)
    async def pick_channel(self, interaction: discord.Interaction, select: discord.ui.ChannelSelect):
        self.st.channel_id = select.values[0].id
        await self.refresh(interaction)

    # ----- Fila 3: enviar / cancelar -----
    @discord.ui.button(label="Enviar", emoji="📤", style=discord.ButtonStyle.success, row=3)
    async def btn_send(self, interaction: discord.Interaction, button: discord.ui.Button):
        st = self.st
        if st.is_empty():
            await interaction.response.send_message("❌ El embed está vacío.", ephemeral=True)
            return
        channel = interaction.guild.get_channel(st.channel_id or self.default_channel)
        if channel is None or not hasattr(channel, "send"):
            await interaction.response.send_message("❌ Canal no válido.", ephemeral=True)
            return
        if not channel.permissions_for(interaction.user).send_messages:
            await interaction.response.send_message("❌ Tú no puedes escribir en ese canal.", ephemeral=True)
            return
        perms = channel.permissions_for(interaction.guild.me)
        if not (perms.send_messages and perms.embed_links):
            await interaction.response.send_message(
                "❌ No tengo permisos de **Enviar mensajes** e **Insertar enlaces** en ese canal.", ephemeral=True)
            return

        await interaction.response.defer()
        embed, uploads = build_custom_embed(st, for_send=True)
        embed = apply_vars_to_embed(embed, variable_values(
            user=interaction.user, guild=interaction.guild, channel=interaction.channel))
        try:
            files = [await att.to_file(filename=name) for att, name in uploads]
            await channel.send(embed=embed, files=files)
        except discord.HTTPException as e:
            await interaction.followup.send(f"❌ No pude enviar el embed: {e}", ephemeral=True)
            return
        await interaction.edit_original_response(content=f"✅ Embed enviado en {channel.mention}.",
                                                 embed=None, view=None)
        self.stop()

    @discord.ui.button(label="Guardar", emoji="💾", style=discord.ButtonStyle.primary, row=3)
    async def btn_save(self, interaction: discord.Interaction, button: discord.ui.Button):
        if self.save_name:
            await self.save(interaction, self.save_name)
        else:
            await interaction.response.send_modal(SaveNameModal(self))

    @discord.ui.button(label="Variables", emoji="📚", style=discord.ButtonStyle.secondary, row=3)
    async def btn_variables(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_message(embeds=variables_embeds(), ephemeral=True)

    @discord.ui.button(label="Cancelar", emoji="🗑️", style=discord.ButtonStyle.danger, row=3)
    async def btn_cancel(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.edit_message(content="🗑️ Cancelado.", embed=None, view=None)
        self.stop()


async def embed_names_ac(interaction: discord.Interaction, current: str):
    names = sorted(embed_store(interaction.guild_id)) if interaction.guild_id else []
    return [app_commands.Choice(name=n, value=n) for n in names if current.lower() in n][:25]


@bot.tree.command(name="embed", description="🧩 Crea, guarda y envía embeds personalizados")
@app_commands.describe(create="Nombre para crear o editar un embed guardado (opcional)",
                       imagen="Imagen grande (adjunta, opcional)", icono="Icono / miniatura (adjunta, opcional)")
@app_commands.autocomplete(create=embed_names_ac)
@app_commands.guild_only()
@app_commands.checks.has_permissions(manage_messages=True)
@requires_key()
async def embed_cmd(interaction: discord.Interaction, create: Optional[str] = None,
                    imagen: Optional[discord.Attachment] = None, icono: Optional[discord.Attachment] = None):
    for att in (imagen, icono):
        if att and not (att.content_type or "").startswith("image/"):
            await interaction.response.send_message("❌ Los adjuntos deben ser imágenes.", ephemeral=True)
            return
    name, state = None, EmbedState(imagen, icono)
    if create:
        name = clean_embed_name(create)
        if not name:
            await interaction.response.send_message(
                "❌ Nombre inválido. Usa letras minúsculas, números, `-` y `_` (máx. 32).", ephemeral=True)
            return
        saved = embed_store(interaction.guild.id).get(name)
        if saved:  # editar uno existente
            state = EmbedState.from_dict(saved)
            state.image_att, state.thumb_att = imagen, icono
    view = EmbedBuilderView(interaction.user.id, state, interaction.channel.id, save_name=name)
    await interaction.response.send_message(content=view.dest_text(), embed=view.preview(), view=view,
                                            ephemeral=True)
    view.message = await interaction.original_response()


@bot.tree.command(name="embed_send", description="📤 Envía un embed guardado a un canal")
@app_commands.describe(nombre="Nombre del embed guardado", canal="Canal de destino (por defecto, este)")
@app_commands.autocomplete(nombre=embed_names_ac)
@app_commands.guild_only()
@app_commands.checks.has_permissions(manage_messages=True)
@requires_key()
async def embed_send(interaction: discord.Interaction, nombre: str, canal: Optional[discord.TextChannel] = None):
    canal = canal or interaction.channel
    name = clean_embed_name(nombre) or nombre
    emb = render_saved_embed(interaction.guild.id, name, variable_values(
        user=interaction.user, guild=interaction.guild, channel=canal))
    if emb is None:
        await interaction.response.send_message("❌ No existe ese embed. Mira la lista con `/embed_list`.",
                                                ephemeral=True)
        return
    try:
        await canal.send(embed=emb)
    except discord.HTTPException as exc:
        await interaction.response.send_message(f"❌ No pude enviarlo: {exc}", ephemeral=True)
        return
    await interaction.response.send_message(f"✅ Embed `{name}` enviado en {canal.mention}.", ephemeral=True)


@bot.tree.command(name="embed_list", description="📋 Lista tus embeds guardados y dónde se usan")
@app_commands.guild_only()
@requires_key()
async def embed_list(interaction: discord.Interaction):
    store = embed_store(interaction.guild.id)
    if not store:
        await interaction.response.send_message("No hay embeds guardados. Crea uno con `/embed create:nombre`.",
                                                ephemeral=True)
        return
    uses: dict[str, list] = defaultdict(list)
    for cat, meta in CATS.items():
        cfg = gcfg(interaction.guild.id, cat)
        for key, label, kind in meta["vars"]:
            if kind == "embed" and cfg.get(key):
                uses[cfg[key]].append(f"{meta['name']} → {label.split(' ', 1)[-1]}")
    lines = [f"🖼️ `{n}` — {', '.join(uses[n]) if uses.get(n) else '*sin usar*'}" for n in sorted(store)]
    await interaction.response.send_message(embed=discord.Embed(
        title=f"🖼️ Embeds guardados ({len(store)}/{MAX_SAVED_EMBEDS})", description="\n".join(lines)[:4000],
        color=0x8B5CF6), ephemeral=True)


@bot.tree.command(name="embed_delete", description="🗑️ Borra un embed guardado")
@app_commands.describe(nombre="Nombre del embed guardado")
@app_commands.autocomplete(nombre=embed_names_ac)
@app_commands.guild_only()
@app_commands.checks.has_permissions(manage_guild=True)
@requires_key()
async def embed_delete(interaction: discord.Interaction, nombre: str):
    name = clean_embed_name(nombre) or nombre
    if embed_store(interaction.guild.id).pop(name, None) is None:
        await interaction.response.send_message("❌ No existe ese embed.", ephemeral=True)
        return
    unlink_embed(interaction.guild.id, name)
    save_data()
    await interaction.response.send_message(f"🗑️ Embed `{name}` eliminado (y desvinculado del panel).",
                                            ephemeral=True)


# =====================================================================
#  BIENVENIDA / DESPEDIDA / AUTOROL
# =====================================================================
def variable_values(*, user=None, guild=None, channel=None, alliance=None, extra=None) -> dict[str, str]:
    """Construye variables para texto; valores sin contexto se sustituyen por cadena vacía."""
    now = discord.utils.utcnow()
    values: dict[str, str] = {
        "{date}": now.strftime("%d/%m/%Y"),
        "{time}": now.strftime("%H:%M UTC"),
        "{server}": getattr(guild, "name", "") or "",
        "{server_id}": str(getattr(guild, "id", "") or ""),
        "{count}": str(getattr(guild, "member_count", "") or ""),
        "{server_icon}": str(getattr(getattr(guild, "icon", None), "url", "") or ""),
        "{server_banner}": str(getattr(getattr(guild, "banner", None), "url", "") or ""),
        "{channel}": getattr(channel, "mention", "") or "",
        "{channel_name}": getattr(channel, "name", "") or "",
        "{channel_id}": str(getattr(channel, "id", "") or ""),
        "{user}": getattr(user, "mention", "") or "",
        "{mention}": getattr(user, "mention", "") or "",
        "{username}": getattr(user, "name", "") or "",
        "{displayname}": getattr(user, "display_name", getattr(user, "name", "")) or "",
        "{id}": str(getattr(user, "id", "") or ""),
        "{user_avatar}": str(getattr(getattr(user, "display_avatar", None), "url", "") or ""),
        "{avatar}": str(getattr(getattr(user, "display_avatar", None), "url", "") or ""),
        "{created_at}": getattr(user, "created_at", now).strftime("%d/%m/%Y") if user else "",
        "{joined_at}": getattr(user, "joined_at", None).strftime("%d/%m/%Y") if getattr(user, "joined_at", None) else "",
    }
    if alliance:
        rep = alliance.get("representative")
        inviter = alliance.get("inviter")
        values.update({
            "{representative}": getattr(rep, "display_name", "") or "",
            "{rep}": getattr(rep, "display_name", "") or "",
            "{representative_mention}": getattr(rep, "mention", "") or "",
            "{rep_mention}": getattr(rep, "mention", "") or "",
            "{representative_avatar}": str(getattr(getattr(rep, "display_avatar", None), "url", "") or ""),
            "{rep_avatar}": str(getattr(getattr(rep, "display_avatar", None), "url", "") or ""),
            "{inviter}": getattr(inviter, "display_name", "") or "",
            "{registered_by}": getattr(inviter, "display_name", "") or "",
            "{inviter_mention}": getattr(inviter, "mention", "") or "",
            "{registered_by_mention}": getattr(inviter, "mention", "") or "",
            "{inviter_avatar}": str(getattr(getattr(inviter, "display_avatar", None), "url", "") or ""),
            "{registered_by_avatar}": str(getattr(getattr(inviter, "display_avatar", None), "url", "") or ""),
            "{alliance_name}": str(alliance.get("name", "") or ""),
            "{alliance_invite}": str(alliance.get("invite", "") or ""),
            "{alliance_description}": str(alliance.get("description", "") or ""),
        })
    if extra:  # variables propias de cada función: {prize}, {level}, {reason}, {ticket}…
        values.update({k: str(v) for k, v in extra.items()})
    return values


def replace_variables(template: Optional[str], values: dict[str, str]) -> Optional[str]:
    if template is None:
        return None
    for token, value in values.items():
        template = template.replace(token, value)
    return template


def fill(template: str, member: discord.Member) -> str:
    """Aplica las variables disponibles en bienvenida y despedida."""
    return replace_variables(template, variable_values(user=member, guild=member.guild)) or ""


def fill_embed_text(template: Optional[str], interaction: discord.Interaction) -> Optional[str]:
    """Aplica variables en textos de embeds con el contexto del comando."""
    if template is None:
        return None
    return replace_variables(template, variable_values(
        user=interaction.user, guild=interaction.guild, channel=interaction.channel
    ))


# ---------- EMBEDS GUARDADOS (/embed create:nombre) reutilizables en cualquier función ----------
EMBED_NAME_RE = re.compile(r"^[a-z0-9_-]{1,32}$")
MAX_SAVED_EMBEDS = 25


def embed_store(guild_id: int) -> dict:
    return data["embeds"].setdefault(str(guild_id), {})


def clean_embed_name(raw: str) -> Optional[str]:
    n = raw.strip().lower().replace(" ", "-")
    return n if EMBED_NAME_RE.fullmatch(n) else None


def _valid_img(u: Optional[str]) -> Optional[str]:
    return u if u and u.startswith(("http://", "https://", "attachment://")) else None


def apply_vars_to_embed(src: discord.Embed, values: dict) -> discord.Embed:
    """Copia el embed reemplazando variables en todos sus textos y URLs."""
    rv = lambda t: replace_variables(t, values) if t else t  # noqa: E731
    e = discord.Embed.from_dict(src.to_dict())
    e.title = rv(src.title) or None
    e.description = rv(src.description) or None
    if src.author and src.author.name:
        name = rv(src.author.name)
        icon = _valid_img(rv(str(src.author.icon_url))) if src.author.icon_url else None
        if name:
            e.set_author(name=name, icon_url=icon)
        else:
            e.remove_author()
    if src.footer and src.footer.text:
        text = rv(src.footer.text)
        icon = _valid_img(rv(str(src.footer.icon_url))) if src.footer.icon_url else None
        if text:
            e.set_footer(text=text, icon_url=icon)
        else:
            e.remove_footer()
    if src.image and src.image.url:
        e.set_image(url=_valid_img(rv(str(src.image.url))))
    if src.thumbnail and src.thumbnail.url:
        e.set_thumbnail(url=_valid_img(rv(str(src.thumbnail.url))))
    e.clear_fields()
    for f in src.fields:
        e.add_field(name=rv(f.name) or "\u200b", value=rv(f.value) or "\u200b", inline=f.inline)
    return e


def render_saved_embed(guild_id: int, name: Optional[str], values: dict) -> Optional[discord.Embed]:
    """Devuelve el embed guardado con las variables aplicadas, o None si no existe."""
    if not name:
        return None
    d = data["embeds"].get(str(guild_id), {}).get(name)
    if not d:
        return None
    st = EmbedState.from_dict(d)
    if st.is_empty():
        return None
    base, _ = build_custom_embed(st)
    return apply_vars_to_embed(base, values)


async def send_saved(dest, guild_id: int, name: Optional[str], values: dict, **kwargs) -> bool:
    """Envía el embed guardado `name` a `dest`. True si existía (aunque falle el envío)."""
    emb = render_saved_embed(guild_id, name, values)
    if emb is None:
        return False
    try:
        await dest.send(embed=emb, **kwargs)
    except discord.HTTPException:
        pass
    return True


def unlink_embed(guild_id: int, name: str) -> None:
    """Quita un embed borrado de todas las variables del panel que lo usaban."""
    for cat, meta in CATS.items():
        cfg = gcfg(guild_id, cat)
        for key, _, kind in meta["vars"]:
            if kind == "embed" and cfg.get(key) == name:
                cfg[key] = None


async def handle_welcome(member: discord.Member):
    guild = member.guild
    cfg = gcfg(guild.id, "bienvenida")

    if cfg["autorole"]:
        role = guild.get_role(cfg["autorole"])
        if role:
            try:
                await member.add_roles(role, reason="Autorol")
            except discord.HTTPException:
                pass

    if not cfg["welcome_on"]:
        return
    text = fill(cfg["welcome_msg"], member)
    if cfg["welcome_channel"]:
        ch = guild.get_channel(cfg["welcome_channel"])
        if ch:
            ctx = variable_values(user=member, guild=guild, channel=ch)
            if not await send_saved(ch, guild.id, cfg.get("welcome_embed"), ctx, content=member.mention):
                try:
                    if cfg["use_embed"]:
                        e = discord.Embed(title=fill(cfg["welcome_title"], member), description=text, color=0x2ECC71)
                        e.set_thumbnail(url=member.display_avatar.url)
                        if cfg["welcome_image"].startswith("http"):
                            e.set_image(url=cfg["welcome_image"])
                        await ch.send(embed=e)
                    else:
                        await ch.send(text)
                except discord.HTTPException:
                    pass
    if cfg["welcome_dm"]:
        ctx = variable_values(user=member, guild=guild)
        if not await send_saved(member, guild.id, cfg.get("welcome_embed"), ctx):
            try:
                await member.send(text)
            except discord.HTTPException:
                pass


async def handle_goodbye(member: discord.Member):
    guild = member.guild
    cfg = gcfg(guild.id, "bienvenida")
    if not (cfg["goodbye_on"] and cfg["goodbye_channel"]):
        return
    ch = guild.get_channel(cfg["goodbye_channel"])
    if not ch:
        return
    ctx = variable_values(user=member, guild=guild, channel=ch)
    if await send_saved(ch, guild.id, cfg.get("goodbye_embed"), ctx):
        return
    text = fill(cfg["goodbye_msg"], member)
    try:
        if cfg["use_embed"]:
            e = discord.Embed(description=text, color=0x95A5A6)
            e.set_thumbnail(url=member.display_avatar.url)
            await ch.send(embed=e)
        else:
            await ch.send(text)
    except discord.HTTPException:
        pass


# =====================================================================
#  ALIADOS Y AFILIADOS (alianzas con otros servidores)
# =====================================================================
INVITE_RE = re.compile(r"(discord\.gg|discord\.com/invite)/\S+", re.I)


@bot.tree.command(name="ally_add", description="🤝 Registra una alianza con otro servidor")
@app_commands.describe(nombre="Nombre del servidor aliado", invitacion="Enlace de invitación",
                       representante="Representante del servidor aliado", descripcion="Descripción (opcional)")
@app_commands.guild_only()
@app_commands.checks.has_permissions(manage_guild=True)
@requires_key()
async def alianza_registrar(interaction: discord.Interaction, nombre: str, invitacion: str,
                            representante: discord.Member, descripcion: str = ""):
    guild = interaction.guild
    cfg = gcfg(guild.id, "aliados")
    if not cfg["enabled"]:
        await interaction.response.send_message("🤝 El módulo de alianzas está desactivado (actívalo en `/panel`).",
                                                ephemeral=True)
        return
    ch = guild.get_channel(cfg["channel"]) if cfg["channel"] else None
    if ch is None:
        await interaction.response.send_message("❌ Configura el **canal de alianzas** en `/panel`.", ephemeral=True)
        return
    if not INVITE_RE.search(invitacion):
        await interaction.response.send_message("❌ Pon un enlace de invitación válido (discord.gg/…).",
                                                ephemeral=True)
        return
    if not invitacion.lower().startswith("http"):
        invitacion = "https://" + invitacion.strip()

    store = data["allies"].setdefault(str(guild.id), {})
    key = nombre.strip().lower()
    if key in store:
        await interaction.response.send_message("❌ Ya existe una alianza con ese nombre.", ephemeral=True)
        return

    alliance_context = {
        "name": nombre.strip(), "invite": invitacion, "description": descripcion,
        "representative": representante, "inviter": interaction.user,
    }
    alliance_vars = variable_values(user=interaction.user, guild=guild, channel=ch, alliance=alliance_context)
    title = replace_variables("🤝 Nueva alianza: {alliance_name}", alliance_vars) or "🤝 Nueva alianza"
    desc = replace_variables(descripcion or "¡Nueva alianza!", alliance_vars) or "¡Nueva alianza!"
    e = discord.Embed(title=title, description=desc, color=0x1ABC9C)
    e.add_field(name="🔗 Invitación", value=replace_variables("{alliance_invite}", alliance_vars) or invitacion, inline=False)
    e.add_field(name="👤 Representante", value=replace_variables("{representative_mention}", alliance_vars) or representante.mention)
    e.add_field(name="🛠️ Registrada por", value=replace_variables("{inviter_mention}", alliance_vars) or interaction.user.mention)
    e.set_author(name=interaction.user.display_name, icon_url=interaction.user.display_avatar.url)
    e.set_thumbnail(url=representante.display_avatar.url)
    if guild.icon:
        e.set_image(url=guild.icon.url)
    e.set_footer(text=replace_variables(cfg["thanks"], alliance_vars) or "🤝 Gracias por la alianza")
    custom = render_saved_embed(guild.id, cfg.get("embed"), alliance_vars)
    if custom is not None:
        e = custom
    try:
        await ch.send(embed=e)
    except discord.HTTPException:
        await interaction.response.send_message("❌ No pude enviar el mensaje en el canal de alianzas.",
                                                ephemeral=True)
        return

    role_note = ""
    if cfg["role"]:
        role = guild.get_role(cfg["role"])
        if role:
            try:
                await representante.add_roles(role, reason=f"Alianza con {nombre}")
            except discord.HTTPException:
                role_note = " (no pude darle el rol, revisa mi jerarquía)"

    store[key] = {"name": nombre.strip(), "invite": invitacion, "rep": representante.id,
                  "by": interaction.user.id, "ts": int(time.time())}
    save_data()
    await interaction.response.send_message(f"✅ Alianza con **{nombre}** registrada.{role_note}", ephemeral=True)


@bot.tree.command(name="ally_list", description="📋 Lista de alianzas del servidor")
@app_commands.guild_only()
@requires_key()
async def alianza_lista(interaction: discord.Interaction):
    store = data["allies"].get(str(interaction.guild.id), {})
    if not store:
        await interaction.response.send_message("Aún no hay alianzas registradas.", ephemeral=True)
        return
    lines = [f"**{a['name']}** — <@{a['rep']}> — [invitación]({a['invite']}) — <t:{a['ts']}:d>"
             for a in list(store.values())[:25]]
    await interaction.response.send_message(embed=discord.Embed(
        title=f"🤝 Alianzas ({len(store)})", description="\n".join(lines)[:4000], color=0x1ABC9C))


@bot.tree.command(name="ally_remove", description="🗑️ Elimina una alianza")
@app_commands.describe(nombre="Nombre exacto de la alianza")
@app_commands.guild_only()
@app_commands.checks.has_permissions(manage_guild=True)
@requires_key()
async def alianza_quitar(interaction: discord.Interaction, nombre: str):
    guild = interaction.guild
    store = data["allies"].get(str(guild.id), {})
    ally = store.pop(nombre.strip().lower(), None)
    if not ally:
        await interaction.response.send_message("❌ No encontré esa alianza.", ephemeral=True)
        return
    cfg = gcfg(guild.id, "aliados")
    still_rep = any(a["rep"] == ally["rep"] for a in store.values())
    member = guild.get_member(ally["rep"])
    role = guild.get_role(cfg["role"]) if cfg["role"] else None
    if member and role and not still_rep:
        try:
            await member.remove_roles(role, reason="Alianza terminada")
        except discord.HTTPException:
            pass
    save_data()
    await interaction.response.send_message(f"🗑️ Alianza con **{ally['name']}** eliminada.", ephemeral=True)


# =====================================================================
#  GESTIÓN DE ACCESO AL PANEL (solo el dueño)
# =====================================================================
@bot.tree.command(name="sys_grant", description="➕ Autoriza a alguien a usar el panel y los comandos admin")
@app_commands.guild_only()
@owner_only()
@requires_key()
async def acceso_agregar(interaction: discord.Interaction, usuario: discord.Member):
    if usuario.bot:
        await interaction.response.send_message("❌ No puedes autorizar a un bot.", ephemeral=True)
        return
    if usuario.id == OWNER_ID:
        await interaction.response.send_message("Ya eres el dueño del bot.", ephemeral=True)
        return
    allowed = data.setdefault("allowed", [])
    if usuario.id in allowed:
        await interaction.response.send_message("Esa persona ya tiene acceso.", ephemeral=True)
        return
    allowed.append(usuario.id)
    save_data()
    await interaction.response.send_message(
        f"✅ {usuario.mention} ahora puede usar `/acceso` (necesitará la key que tú le des).", ephemeral=True)


@bot.tree.command(name="sys_revoke", description="➖ Quita el acceso a alguien")
@app_commands.describe(usuario_id="ID del usuario")
@app_commands.guild_only()
@owner_only()
@requires_key()
async def acceso_quitar(interaction: discord.Interaction, usuario_id: str):
    if not usuario_id.strip().isdigit():
        await interaction.response.send_message("❌ Debes dar un ID numérico.", ephemeral=True)
        return
    uid = int(usuario_id.strip())
    allowed = data.setdefault("allowed", [])
    if uid not in allowed:
        await interaction.response.send_message("Esa persona no estaba autorizada.", ephemeral=True)
        return
    allowed.remove(uid)
    auth_sessions.pop(uid, None)  # su sesión se cierra al instante
    save_data()
    await interaction.response.send_message(f"✅ Acceso revocado a `{uid}`.", ephemeral=True)


@bot.tree.command(name="sys_accesslist", description="📋 Quién tiene acceso al panel")
@app_commands.guild_only()
@owner_only()
@requires_key()
async def acceso_lista(interaction: discord.Interaction):
    allowed = data.get("allowed", [])
    text = f"👑 <@{OWNER_ID}> (dueño)\n" + "\n".join(f"🔑 <@{u}> (`{u}`)" for u in allowed)
    await interaction.response.send_message(
        embed=discord.Embed(title="🔐 Acceso autorizado", description=text, color=0x5865F2), ephemeral=True)


# =====================================================================
#  GESTIÓN VISUAL DE CANALES Y ROLES (opciones nativas de Discord)
# =====================================================================
def _guild_manage_guard(interaction: discord.Interaction) -> bool:
    return bool(interaction.guild and guild_is_allowed(interaction.guild.id))


@bot.tree.command(name="canal_nombre", description="📝 Cambia el nombre de un canal usando selector de Discord")
@app_commands.guild_only()
@app_commands.describe(canal="Elige el canal", nombre="Nuevo nombre, sin #")
@requires_key()
async def canal_nombre(interaction: discord.Interaction, canal: discord.abc.GuildChannel, nombre: str):
    if not _guild_manage_guard(interaction):
        await interaction.response.send_message("🔒 Este servidor no está autorizado para Luminos Nova.", ephemeral=True)
        return
    if not interaction.user.guild_permissions.manage_channels:
        await interaction.response.send_message("⛔ Necesitas el permiso Gestionar canales.", ephemeral=True)
        return
    try:
        await canal.edit(name=nombre.strip().lower().replace(" ", "-")[:100], reason=f"Luminos Nova por {interaction.user}")
        await interaction.response.send_message(f"✅ Canal actualizado: {canal.mention if hasattr(canal, 'mention') else canal.name}", ephemeral=True)
    except discord.Forbidden:
        await interaction.response.send_message("❌ Al bot le falta Gestionar canales o su rol está demasiado bajo.", ephemeral=True)
    except discord.HTTPException as exc:
        await interaction.response.send_message(f"❌ Discord rechazó el cambio: {exc}", ephemeral=True)


@bot.tree.command(name="canal_emoji", description="✨ Añade un emoji al principio del nombre de un canal")
@app_commands.guild_only()
@app_commands.describe(canal="Elige el canal", emoji="Emoji que irá al principio", nombre="Texto del canal")
@requires_key()
async def canal_emoji(interaction: discord.Interaction, canal: discord.abc.GuildChannel, emoji: str, nombre: str):
    if not _guild_manage_guard(interaction):
        await interaction.response.send_message("🔒 Este servidor no está autorizado para Luminos Nova.", ephemeral=True)
        return
    if not interaction.user.guild_permissions.manage_channels:
        await interaction.response.send_message("⛔ Necesitas el permiso Gestionar canales.", ephemeral=True)
        return
    clean = re.sub(r"\s+", "-", nombre.strip().lower())
    try:
        await canal.edit(name=f"{emoji.strip()}-{clean}"[:100], reason=f"Luminos Nova por {interaction.user}")
        await interaction.response.send_message(f"✨ Nombre actualizado a `{canal.name}`.", ephemeral=True)
    except (discord.Forbidden, discord.HTTPException) as exc:
        await interaction.response.send_message(f"❌ No se pudo editar el canal: {exc}", ephemeral=True)


@bot.tree.command(name="canal_mover", description="📂 Mueve un canal a otra categoría")
@app_commands.guild_only()
@app_commands.describe(canal="Canal que quieres mover", categoria="Categoría de destino")
@requires_key()
async def canal_mover(interaction: discord.Interaction, canal: discord.abc.GuildChannel, categoria: discord.CategoryChannel):
    if not _guild_manage_guard(interaction):
        await interaction.response.send_message("🔒 Este servidor no está autorizado para Luminos Nova.", ephemeral=True)
        return
    if not interaction.user.guild_permissions.manage_channels:
        await interaction.response.send_message("⛔ Necesitas el permiso Gestionar canales.", ephemeral=True)
        return
    try:
        await canal.edit(category=categoria, reason=f"Luminos Nova por {interaction.user}")
        await interaction.response.send_message(f"📂 {canal.name} se movió a **{categoria.name}**.", ephemeral=True)
    except (discord.Forbidden, discord.HTTPException) as exc:
        await interaction.response.send_message(f"❌ No se pudo mover el canal: {exc}", ephemeral=True)


@bot.tree.command(name="rol_nombre", description="🏷️ Cambia el nombre de un rol")
@app_commands.guild_only()
@app_commands.describe(rol="Elige el rol", nombre="Nuevo nombre; puedes incluir emojis")
@requires_key()
async def rol_nombre(interaction: discord.Interaction, rol: discord.Role, nombre: str):
    if not _guild_manage_guard(interaction):
        await interaction.response.send_message("🔒 Este servidor no está autorizado para Luminos Nova.", ephemeral=True)
        return
    if not interaction.user.guild_permissions.manage_roles:
        await interaction.response.send_message("⛔ Necesitas el permiso Gestionar roles.", ephemeral=True)
        return
    try:
        await rol.edit(name=nombre.strip()[:100], reason=f"Luminos Nova por {interaction.user}")
        await interaction.response.send_message(f"🏷️ Rol renombrado a **{rol.name}**.", ephemeral=True)
    except (discord.Forbidden, discord.HTTPException) as exc:
        await interaction.response.send_message(f"❌ No se pudo editar el rol: {exc}", ephemeral=True)


@bot.tree.command(name="rol_color", description="🎨 Cambia el color de un rol con un código hexadecimal")
@app_commands.guild_only()
@app_commands.describe(rol="Elige el rol", color="Color hexadecimal, por ejemplo #8B5CF6")
@requires_key()
async def rol_color(interaction: discord.Interaction, rol: discord.Role, color: str):
    if not _guild_manage_guard(interaction):
        await interaction.response.send_message("🔒 Este servidor no está autorizado para Luminos Nova.", ephemeral=True)
        return
    if not interaction.user.guild_permissions.manage_roles:
        await interaction.response.send_message("⛔ Necesitas el permiso Gestionar roles.", ephemeral=True)
        return
    raw = color.strip().removeprefix("#")
    if not re.fullmatch(r"[0-9a-fA-F]{6}", raw):
        await interaction.response.send_message("Usa un color hexadecimal válido, por ejemplo `#8B5CF6`.", ephemeral=True)
        return
    try:
        await rol.edit(colour=discord.Colour(int(raw, 16)), reason=f"Luminos Nova por {interaction.user}")
        await interaction.response.send_message(f"🎨 Color de **{rol.name}** actualizado.", ephemeral=True)
    except (discord.Forbidden, discord.HTTPException) as exc:
        await interaction.response.send_message(f"❌ No se pudo editar el rol: {exc}", ephemeral=True)


@bot.tree.command(name="rol_orden", description="↕️ Cambia la posición de un rol en la lista")
@app_commands.guild_only()
@app_commands.describe(rol="Elige el rol", posicion="Posición deseada (más alto = más arriba)")
@requires_key()
async def rol_orden(interaction: discord.Interaction, rol: discord.Role, posicion: app_commands.Range[int, 1, 250]):
    if not _guild_manage_guard(interaction):
        await interaction.response.send_message("🔒 Este servidor no está autorizado para Luminos Nova.", ephemeral=True)
        return
    if not interaction.user.guild_permissions.manage_roles:
        await interaction.response.send_message("⛔ Necesitas el permiso Gestionar roles.", ephemeral=True)
        return
    try:
        await rol.edit(position=posicion, reason=f"Luminos Nova por {interaction.user}")
        await interaction.response.send_message(f"↕️ Posición de **{rol.name}** actualizada.", ephemeral=True)
    except (discord.Forbidden, discord.HTTPException) as exc:
        await interaction.response.send_message(f"❌ No se pudo mover el rol: {exc}", ephemeral=True)


# =====================================================================
#  INICIO
# =====================================================================
if __name__ == "__main__":
    _token = get_token(CONFIG)
    try:
        bot.run(_token)
    finally:
        save_data()